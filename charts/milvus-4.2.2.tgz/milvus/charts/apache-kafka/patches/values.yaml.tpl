global:
  # -- Global override for the storage class
  storageClassName: ""
  # -- Global override for container image registry
  imageRegistry: ""
  # -- Global override for container image registry pull secrets
  imagePullSecrets: []

# -- Annotations to add to all deployed objects
commonAnnotations: {}
# -- Labels to add to all deployed objects
commonLabels: {}
# -- Override the resource name
fullnameOverride: ""
# -- Override the resource name prefix (will keep the release name)
nameOverride: ""
# -- Additional Kubernetes manifests to include in the chart
extraManifests: []
# -- Kubernetes cluster domain name
clusterDomain: cluster.local

images:
  controller:
    # -- Image registry to use for the Apache Kafka controller container
    registry: ${CONTAINER_REGISTRY}
    # -- Image repository to use for the Apache Kafka controller container
    repository: containers/apache-kafka
    # -- Image tag to use for the Apache Kafka controller container
    tag: "${APP_VERSION}"
    # -- Image digest to use for the Apache Kafka controller container (if set, `images.controller.tag` will be ignored)
    digest: ""
    # -- Image pull policy to use for the Apache Kafka controller container
    pullPolicy: IfNotPresent
  broker:
    # -- Image registry to use for the Apache Kafka broker container
    registry: ${CONTAINER_REGISTRY}
    # -- Image repository to use for the Apache Kafka broker container
    repository: containers/apache-kafka
    # -- Image tag to use for the Apache Kafka broker container
    tag: "${APP_VERSION}"
    # -- Image digest to use for the Apache Kafka broker container (if set, `images.broker.tag` will be ignored)
    digest: ""
    # -- Image pull policy to use for the Apache Kafka broker container
    pullPolicy: IfNotPresent
  volume-permissions:
    # -- Image registry to use for the volume permissions init container
    registry: ${CONTAINER_REGISTRY}
    # -- Image pository to use for the volume permissions init container
    repository: containers/bci-busybox
    # -- Image tag to use for the volume permissions init container
    tag: "15.6"
    # -- Image digest to use for the volume permissions init container (if set, `images.volume-permissions.tag` will be ignored)
    digest: ""
    # -- Image pull policy to use for the volume-permissions container
    pullPolicy: IfNotPresent

containerPorts:
  # -- (int32) Apache Kafka port number for client connections
  client: 9092
  # -- (int32) Apache Kafka port number for controller connections
  controller: 9093
  # -- (int32) Apache Kafka port number for interbroker connections
  interbroker: 9094
  # -- (int32) Custom port number to expose in the Apache Kafka containers
  "*":
  # Note: This field is only added for documentation purposes

cluster:
  listeners:
    client:
      # -- Apache Kafka client's listener name
      name: CLIENT
      # -- Apache Kafka client's listener security protocol. Valid values are `PLAINTEXT`, `SASL_PLAINTEXT`, `SSL` and `SASL_SSL`
      ## Note: enabling `auth.enabled` and/or `tls/enabled` may be necessary depending on the selected protocol
      protocol: SASL_PLAINTEXT
      # -- Apache Kafka client's listener SASL mechanism. Valid values are `GSSAPI`, `OAUTHBEARER`, and `PLAIN`
      ## Note: used mechanism must be set in `auth.sasl.enabledMechanisms`
      saslMechanism: PLAIN
    controller:
      # -- Apache Kafka controller's listener name
      name: CONTROLLER
      # -- Apache Kafka controller's listener security protocol. Valid values are `PLAINTEXT`, `SASL_PLAINTEXT`, `SSL` and `SASL_SSL`
      ## Note: enabling `auth.enabled` and/or `tls/enabled` may be necessary depending on the selected protocol
      protocol: SASL_PLAINTEXT
      # -- Apache Kafka controller's listener SASL mechanism. Valid values are `GSSAPI`, `OAUTHBEARER`, and `PLAIN`
      ## Note: used mechanism must be set in `auth.sasl.enabledMechanisms`
      saslMechanism: PLAIN
    interbroker:
      # -- Apache Kafka interbroker's listener name
      name: INTERBROKER
      # -- Apache Kafka interbroker's listener security protocol. Valid values are `PLAINTEXT`, `SASL_PLAINTEXT`, `SSL` and `SASL_SSL`
      ## Note: enabling `auth.enabled` and/or `tls/enabled` may be necessary depending on the selected protocol
      protocol: SASL_PLAINTEXT
      # -- Apache Kafka interbroker's listener SASL mechanism. Valid values are `GSSAPI`, `OAUTHBEARER`, and `PLAIN`
      ## Note: used mechanism must be set in `auth.sasl.enabledMechanisms`
      saslMechanism: PLAIN
    # -- Custom Apache Kafka listeners
    "*":
  nodeCount:
    # -- (int32) Desired number of Apache Kafka controller nodes to deploy
    controller: 3
    # -- (int32) Desired number of Apache Kafka broker nodes to deploy (requires `broker.enabled`)
    broker: 3
  # -- Whether the controller nodes will also function as brokers
  controllerBrokerRole: true
  # -- Minimum node ID brokers should start from. Should always be greater than `cluster.nodeCount.controller`
  minBrokerID: 1000
  # -- (int32) Number of log partitions per topic
  numPartitions: 1
  # -- (int32) The replication factor for the offsets topic
  offsetsTopicReplicationFactor: 2
  # -- (int32) Number of disks per each Apache Kafka node
  disksPerBroker: 1
  # -- Unique clusterID shared among all nodes
  clusterID: ""
  # -- Name of a configMap containing the clusterID (if set, `cluster.clusterID` will be ignored)
  clusterConfigMap: ""
  # -- clusterID key in the configMap
  # @default `clusterID`
  clusterIDKey: clusterID

auth:
  # -- Enable Apache Kafka password authentication
  enabled: true
  sasl:
    # -- Comma-separated list of enabled SASL mechanisms. Valid values are `GSSAPI`, `OAUTHBEARER`, and `PLAIN`
    ## Note: SCRAM-SHA-256 and SCRAM-SHA-256 mechanisms are not currently supported in Kraft mode
    enabledMechanisms: "PLAIN"
    gssapi:
      # -- The Kerberos principal name that Kafka runs as
      kerberosServiceName: ""
      # -- Name of the secret containing the Apache Kafka keyTab
      ## Note: The secret must contain a keytab file per node. 
      ## Each keytab must follow the "<release-name>-<nodeType>-<N>.keytab" naming schema
      ## For a cluster with 3 controller and 3 broker nodes we'll need:
      ## - <release-name>-controller-[1..3].keytab
      ## - <release-name>-broker-[1..3].keytab
      existingSecret: ""
    plain:
      # -- User for inter-broker communications
      interbrokerUsername: "admin"
      # -- Password for the interbroker user
      interbrokerPassword: "admin_password"
      # -- Username and password key-name map for client-broker communications
      users:
        user_test: password_test
      # -- Name of a secret containing the Apache Kafka password (if set, `auth.user` and `auth.password` will be ignored)
      existingSecret: ""
      # -- Password key in the secret
      # @default `password`
      passwordKey: ""
    oauthbearer:
      # -- The OAuth/OIDC provider URL from which the provider's JWKS (JSON Web Key Set) can be retrieved
      jwksEndpointUrl: ""
      # -- The URL for the OAuth/OIDC identity provider
      tokenEndpointUrl: ""
      # -- Used by brokers to configure the subject (sub) claim, which determines the user for inter-broker connections
      unsecuredLoginClaimSub: ""
tls:
  # -- Enable TLS. Requires setting the proper `auth.listeners.xxxx.protocol`
  enabled: false
  # -- Store format for file-based keys and trust stores. Valid values are `JKS` and `PEM`
  format: "JKS"
  # -- Configures kafka broker to request client authentication. Valid values are `none`, `required` and `requested`
  clientAuth: "none"
  # -- Whether to require Apache Kafka to perform host name verification
  hostnameVerification: true
  # -- Name of the secret containing the Apache Kafka certificates
  ## Note: The secret must contain a keystore file per node
  ## Each keystore must follow the "<release-name>-<nodeType>-<N>.keystore.jks" naming schema
  ## That is, for a cluster with 3 controller and 3 broker nodes using the "JKS" format we'll need:
  ## - <release-name>-controller-[1..3].keystore.jks
  ## - <release-name>-broker-[1..3].keystore.jks
  ##
  ## For a cluster with 3 controller and 2 broker nodes using the "PEM" format:
  ## - <release-name>-controller-[1..3].crt
  ## - <release-name>-controller-[1..3].key
  ## - <release-name>-broker-[1..2].crt
  ## - <release-name>-broker-[1..2].key
  existingSecret: ""
  # -- Password to access the JKS keystore file in case it is encrypted
  keystorePassword: ""
  # -- Truststore filename in the secret
  truststoreFilename: ""
  # -- Password to access the JKS truststore file in case it is encrypted
  truststorePassword: ""
  # -- CA certificate filename in the secret. If the CA certificate is included in the PEM cert, use the same value as `tls.certificateChainFilename`
  caCertFilename: ""
  # -- The password of the private key in the JKS keystores or the PEM keys, depending on `tls.format`
  keystoreKeyPassword: ""

controller:
  # -- Java heapOpts
  heapOpts: "-Xms512M -Xmx512M"
  # -- Configuration file name for the controllers' server properties in the config map
  configurationFile: server.properties
  # -- Extra configurations to add to the controller configuration file. Can be defined as a string, a key-value (string-string) map, or an array of entries.
  configuration: ""
  # -- Name of an existing config map for extra configurations to add to the Apache Kafka configuration file
  existingConfigMap: ""
  # -- ConfigMaps to deploy
  # @default -- See `values.yaml`
  configMap:
    # -- Create a config map for Apache Kafka configuration
    enabled: '{{ and (not .Values.controller.existingConfigMap) (not (empty .Values.controller.configuration)) }}'
    # See: https://kafka.apache.org/documentation/#configuration
    '{{ .Values.controller.configurationFile }}': '{{ tpl (include "configuration" (dict "values" .Values.controller.configuration "context" $)) . }}'
    # -- (string) Custom configuration file to include, templates are allowed both in the config map name and contents
    "*":
    # Note: This field is only added for documentation purposes
  # -- Secrets to deploy
  # @default -- See `values.yaml`
  secret:
    # -- Create a secret for Apache Kafka credentials
    # @default -- `true` if authentication is enabled without existing secret, `false` otherwise
    enabled: '{{ and (eq (include "auth.enabled" .) "true") (not .Values.auth.existingSecret) }}'
    '{{ include "auth.passwordKey" . }}': '{{ default (randAlphaNum 16) .Values.auth.password }}'
    # -- (string) Custom secret to include, templates are allowed both in the secret name and contents
    "*":
    # Note: This field is only added for documentation purposes

  statefulset:
    # -- Enable the StatefulSet template for Apache Kafka standalone mode
    enabled: true
    # -- Override for the Apache Kafka' StatefulSet serviceName field, it will be autogenerated if unset
    serviceName: ""
    # -- Template to use for all pods created by the Apache Kafka StatefulSet (overrides `podTemplates.*`)
    template: {}
    # -- Desired number of PodTemplate replicas for Apache Kafka controller (overrides `cluster.nodeCount.controller`)
    replicas: ""
    # -- Strategy that will be employed to update the pods in the Apache Kafka StatefulSet
    # @default -- See `values.yaml`
    updateStrategy:
      type: RollingUpdate
    # -- How Apache Kafka pods are created during the initial scaleup
    podManagementPolicy: Parallel
    # -- Lifecycle of the persistent volume claims created from Apache Kafka volumeClaimTemplates
    persistentVolumeClaimRetentionPolicy: {}
    #  whenScaled: Retain
    #  whenDeleted: Retain
    # -- Volume claim templates for the Apache Kafka statefulset, templates are allowed in all fields
    # @default -- See `values.yaml`
    # Each field has the volumeClaimTemplate name as key, and a YAML string template with the values; you must set `enabled: true` to enable it
    volumeClaimTemplates:
      data:
        enabled: '{{ .Values.persistence.enabled }}'
      logs:
        enabled: '{{ .Values.persistence.enabled }}'
        volumeCount: '{{ int .Values.cluster.disksPerBroker }}'
    # -- Custom attributes for the Apache Kafka StatefulSet (see [`StatefulSetSpec` API reference](https://kubernetes.io/docs/reference/kubernetes-api/workload-resources/stateful-set-v1/#StatefulSetSpec))
    "*":
    # Note: This field is only added for documentation purposes

  podTemplates:
    # -- Annotations to add to all pods in the Apache Kafka StatefulSet's PodTemplate
    # @default -- See `values.yaml`
    annotations:
      kubectl.kubernetes.io/default-container: controller
    # -- Labels to add to all pods in the Apache Kafka StatefulSet's PodTemplate
    labels: {}
    # -- Number of seconds prior to the container being forcibly terminated when marked for deletion or restarted.
    terminationGracePeriodSeconds: 120
    # -- Init containers to deploy in the Apache Kafka PodTemplate
    # @default -- See `values.yaml`
    # Each field has the init container name as key, and a YAML object template with the values; you must set `enabled: true` to enable it
    initContainers:
      volume-permissions:
        # -- Enable the volume-permissions init container in the Apache Kafka PodTemplate
        enabled: false
        # -- Image override for the Apache Kafka volume-permissions init container (if set, `images.volume-permissions.{name,tag,digest}` values will be ignored for this container)
        image: ""
        # -- Image pull policy override for the Apache Kafka volume-permissions init container (if set `images.volume-permissions.pullPolicy` values will be ignored for this container)
        imagePullPolicy: ""
        # -- Entrypoint override for the Apache Kafka volume-permissions container
        # @default -- See `values.yaml`
        command:
          - /bin/sh
          - -ec
          - |
            chown -R {{ .Values.containerSecurityContext.runAsUser }}:{{ .Values.podSecurityContext.fsGroup }} /mnt/kafka/data
        # -- Arguments override for the Apache Kafka volume-permissions init container entrypoint
        args: []
        # -- Object with the environment variables templates to use in the Apache Kafka volume-permissions init container, the values can be specified as an object or a string; when using objects you must also set `enabled: true` to enable it
        # @default -- No environment variables are set
        env: {}
        # -- List of sources from which to populate environment variables to the Apache Kafka volume-permissions init container (e.g. a ConfigMaps or a Secret)
        envFrom: []
        # -- Custom volume mounts for the Apache Kafka volume-permissions init container, templates are allowed in all fields
        # @default -- See `values.yaml`
        # Each field has the volume mount name as key, and a YAML string template with the values; you must set `enabled: true` to enable it
        volumeMounts:
          data:
            enabled: true
            mountPath: /mnt/kafka/data
        # -- Apache Kafka init-containers resource requirements
        resources: {}
        # We usually recommend not to specify default resources and to leave this as a conscious
        # choice for the user. This also increases chances charts run on environments with little
        # resources, such as Minikube. If you do want to specify resources, uncomment the following
        # lines, adjust them as necessary, and remove the curly braces after 'resources:'
        #   limits:
        #    cpu: 100m
        #    memory: 128Mi
        #   requests:
        #    cpu: 100m
        #    memory: 128Mi
        # -- Security context override for the Apache Kafka volume-permissions init container (if set, `containerSecurityContext.*` values will be ignored for this container)
        # @default -- See `values.yaml`
        securityContext:
          runAsUser: 0
        # -- Custom attributes for the Apache Kafka volume-permissions init container (see [`Container` API spec](https://kubernetes.io/docs/reference/kubernetes-api/workload-resources/pod-v1/#Container))
        "*":
        # Note: This field is only added for documentation purposes
    # -- Containers to deploy in the Apache Kafka PodTemplate
    # @default -- See `values.yaml`
    # Each field has the container name as key, and a YAML object template with the values; you must set `enabled: true` to enable it
    containers:
      controller:
        # -- Enable the Apache Kafka container in the PodTemplate
        enabled: true
        # -- Image override for the Apache Kafka container (if set, `images.controller.{name,tag,digest}` values will be ignored for this container)
        image: ""
        # -- Image pull policy override for the Apache Kafka container (if set `images.controller.pullPolicy` values will be ignored for this container)
        imagePullPolicy: ""
        # -- Entrypoint override for the Apache Kafka container
        # @default -- See `values.yaml`
        command:
          - /bin/bash
          - -ec
          - |
            exec /mnt/kafka/scripts/apache-kafka-entrypoint.sh
        # -- Arguments override for the Apache Kafka container entrypoint
        args: []
        # -- Ports override for the Apache Kafka container (if set, `containerPorts.*` values will be ignored for this container)
        ports: {}
        # -- Object with the environment variables templates to use in the Apache Kafka container, the values can be specified as an object or a string; when using objects you must also set `enabled: true` to enable it
        # @default -- See `values.yaml`
        env:
          # Aux environment variables to be used in the init script
          _KAFKA_POD_HOSTNAME:
            enabled: true
            valueFrom:
              fieldRef:
                fieldPath: metadata.name
          # Aux environment variables to be used in the heathcheck config
          _KAFKA__HEALTHCHECK_PROPERTIES_FILE: '/usr/share/kafka/config/healthcheck.properties'
          _KAFKA_HEALTHCHECK_SECURITY_PROTOCOL: '{{ .Values.cluster.listeners.client.protocol }}'
          _KAFKA_HEALTHCHECK_SASL_JAAS_CONFIG:
            enabled: '{{ and .Values.auth.enabled (contains "SASL" .Values.cluster.listeners.client.protocol) }}'
            value: '{{ include "jaasConfigValue" (dict "listener" .Values.cluster.listeners.client "listenerType" "controller_healthcheck" "nodeType" "controller" "hostname" "$(_KAFKA_POD_HOSTNAME)" "context" $) }}'
          _KAFKA_HEALTHCHECK_SASL_MECHANISM:
            enabled: '{{ and .Values.auth.enabled (contains "SASL" .Values.cluster.listeners.client.protocol) }}'
            value: '{{ .Values.cluster.listeners.client.saslMechanism }}'
          _KAFKA_HEALTHCHECK_SSL_KEYSTORE_LOCATION:
            enabled: '{{ and .Values.tls.enabled (not (eq .Values.tls.clientAuth "none")) }}'
            value: '{{ printf "%s/%s.keystore.jks" .Values.controller.podTemplates.containers.controller.volumeMounts.certs.mountPath "$(_KAFKA_POD_HOSTNAME)" }}'
          _KAFKA_HEALTHCHECK_SSL_KEYSTORE_PASSWORD:
            enabled: '{{ and .Values.tls.enabled (eq .Values.tls.format "JKS") (not (empty .Values.tls.keystorePassword)) (not (eq .Values.tls.clientAuth "none")) }}'
            value: '{{ .Values.tls.keystorePassword }}'
          _KAFKA_HEALTHCHECK_SSL_TRUSTSTORE_LOCATION:
            enabled: '{{ .Values.tls.enabled }}'
            value: '{{ printf "%s/%s" .Values.controller.podTemplates.containers.controller.volumeMounts.certs.mountPath .Values.tls.truststoreFilename }}'
          _KAFKA_HEALTHCHECK_SSL_TRUSTSTORE_PASSWORD:
            enabled: '{{ and .Values.tls.enabled (eq .Values.tls.format "JKS") (not (empty .Values.tls.truststorePassword)) }}'
            value: '{{ .Values.tls.truststorePassword }}'
          _KAFKA_HEALTHCHECK_SSL_KEY_PASSWORD:
            enabled: '{{ and .Values.tls.enabled (not (empty .Values.tls.keystoreKeyPassword)) (not (eq .Values.tls.clientAuth "none")) }}'
            value: '{{ .Values.tls.keystoreKeyPassword }}'
          _KAFKA_HEALTHCHECK_SSL_ENDPOINT_IDENTIFICATION_ALGORITHM:
            enabled: '{{ and .Values.tls.enabled (not .Values.tls.hostnameVerification) }}'
            value: ""
          _KAFKA_HEALTHCHECK_SSL_KEYSTORE_KEY:
            enabled: '{{ and .Values.tls.enabled (eq .Values.tls.format "PEM") (not (eq .Values.tls.clientAuth "none")) }}'
            value: '{{ include "fileToMultilineString" (dict "file" (printf "%s/%s.key" .Values.controller.podTemplates.containers.controller.volumeMounts.certs.mountPath "$(_KAFKA_POD_HOSTNAME)") "context" $) }}'
          _KAFKA_HEALTHCHECK_SSL_KEYSTORE_CERTIFICATE_CHAIN:
            enabled: '{{ and .Values.tls.enabled (eq .Values.tls.format "PEM") }}'
            value: '{{ include "fileToMultilineString" (dict "file" (printf "%s/%s.crt" .Values.controller.podTemplates.containers.controller.volumeMounts.certs.mountPath "$(_KAFKA_POD_HOSTNAME)") "context" $) }}'
          _KAFKA_HEALTHCHECK_SSL_TRUSTORE_CERTIFICATES:
            enabled: '{{ and .Values.tls.enabled (eq .Values.tls.format "PEM") }}'
            value: '{{ include "fileToMultilineString" (dict "file" (printf "%s/%s" .Values.controller.podTemplates.containers.controller.volumeMounts.certs.mountPath (ternary (printf "%s.crt" "$(_KAFKA_POD_HOSTNAME)") .Values.tls.caCertFilename (empty .Values.tls.caCertFilename))) "context" $) }}'
          # General configuration
          KAFKA_PROCESS_ROLES: '{{- ternary "broker,controller" "controller" .Values.cluster.controllerBrokerRole }}'
          KAFKA_CONTROLLER_QUORUM_VOTERS: '{{ include "quorumVoters" . }}'
          KAFKA_LISTENERS: '{{ ternary (include "listeners" (dict "listeners" (list "client" "controller" "interbroker") "nodeType" "controller" "hostname" "$(_KAFKA_POD_HOSTNAME)" "context" $)) (include "listeners" (dict "listeners" (list "controller") "nodeType" "controller" "hostname" "$(_KAFKA_POD_HOSTNAME)" "context" $)) .Values.cluster.controllerBrokerRole }}'
          KAFKA_ADVERTISED_LISTENERS:
            enabled: '{{ .Values.cluster.controllerBrokerRole }}'
            value: '{{ include "listeners" (dict "listeners" (list "client" "interbroker") "nodeType" "controller" "hostname" "$(_KAFKA_POD_HOSTNAME)" "context" $) }}'
          KAFKA_CONTROLLER_LISTENER_NAMES: '{{ .Values.cluster.listeners.controller.name }}'
          KAFKA_INTER_BROKER_LISTENER_NAME:
            enabled: '{{ .Values.cluster.controllerBrokerRole }}'
            value: '{{ .Values.cluster.listeners.interbroker.name }}'
          KAFKA_LOG_DIRS: '{{ include "logDirs" (dict "mountPath" .Values.controller.podTemplates.containers.controller.volumeMounts.logs.mountPath "context" $) }}'
          KAFKA_OFFSETS_TOPIC_REPLICATION_FACTOR:
            enabled: '{{ not (empty .Values.cluster.offsetsTopicReplicationFactor) }}'
            value: '{{ int .Values.cluster.offsetsTopicReplicationFactor }}'
          KAFKA_NUM_PARTITIONS:
            enabled: '{{ not (empty .Values.cluster.numPartitions) }}'
            value: '{{ int .Values.cluster.numPartitions }}'
          KAFKA_HEAP_OPTS:
            enabled: '{{ not (empty .Values.controller.heapOpts) }}'
            value: '{{ .Values.controller.heapOpts }}'
          CLUSTER_ID:
            enabled: true
            valueFrom:
              configMapKeyRef:
                name: '{{ coalesce .Values.cluster.existingConfigMap (include "fullName" (dict "suffix" "cluster" "context" $)) }}'
                key: '{{ .Values.cluster.clusterIDKey }}'
          KAFKA_LISTENER_SECURITY_PROTOCOL_MAP: '{{ include "protocolMap" . }}'
          # SASL configuration
          KAFKA_SASL_MECHANISM_CONTROLLER_PROTOCOL:
            enabled: '{{ and .Values.auth.enabled (contains "SASL" .Values.cluster.listeners.controller.protocol) }}'
            value: '{{ .Values.cluster.listeners.controller.saslMechanism }}'
          KAFKA_SASL_MECHANISM_INTER_BROKER_PROTOCOL:
            enabled: '{{ and .Values.auth.enabled (contains "SASL" .Values.cluster.listeners.interbroker.protocol) }}'
            value: '{{ .Values.cluster.listeners.interbroker.saslMechanism }}'
          KAFKA_SASL_ENABLED_MECHANISMS:
            enabled: '{{ .Values.auth.enabled }}'
            value: '{{ .Values.auth.sasl.enabledMechanisms }}'
          '{{ include "jaasConfigKey" (dict "listener" .Values.cluster.listeners.client "context" $) }}':
            enabled: '{{ and .Values.auth.enabled (contains "SASL" .Values.cluster.listeners.client.protocol) }}'
            value: '{{ include "jaasConfigValue" (dict "listener" .Values.cluster.listeners.client "listenerType" "client" "nodeType" "controller" "hostname" "$(_KAFKA_POD_HOSTNAME)" "context" $) }}'
          '{{ include "jaasConfigKey" (dict "listener" .Values.cluster.listeners.controller "context" $) }}':
            enabled: '{{ and .Values.auth.enabled (contains "SASL" .Values.cluster.listeners.controller.protocol) }}'
            value: '{{ include "jaasConfigValue" (dict "listener" .Values.cluster.listeners.controller "listenerType" "controller" "nodeType" "controller" "hostname" "$(_KAFKA_POD_HOSTNAME)" "context" $) }}'
          '{{ include "jaasConfigKey" (dict "listener" .Values.cluster.listeners.interbroker "context" $) }}':
            enabled: '{{ and .Values.auth.enabled (contains "SASL" .Values.cluster.listeners.interbroker.protocol) }}'
            value: '{{ include "jaasConfigValue" (dict "listener" .Values.cluster.listeners.interbroker "listenerType" "interbroker" "nodeType" "controller" "hostname" "$(_KAFKA_POD_HOSTNAME)" "context" $) }}'
          '{{ printf "%s_%s_%s" "KAFKA_LISTENER_NAME" .Values.cluster.listeners.client.name "SASL_ENABLED_MECHANISMS" }}':
            enabled: '{{ and .Values.auth.enabled (contains "SASL" .Values.cluster.listeners.client.protocol) }}'
            value: '{{ .Values.cluster.listeners.client.saslMechanism }}'
          '{{ printf "%s_%s_%s" "KAFKA_LISTENER_NAME" .Values.cluster.listeners.controller.name "SASL_ENABLED_MECHANISMS" }}':
            enabled: '{{ and .Values.auth.enabled (contains "SASL" .Values.cluster.listeners.controller.protocol) }}'
            value: '{{ .Values.cluster.listeners.controller.saslMechanism }}'
          '{{ printf "%s_%s_%s" "KAFKA_LISTENER_NAME" .Values.cluster.listeners.interbroker.name "SASL_ENABLED_MECHANISMS" }}':
            enabled: '{{ and .Values.auth.enabled (contains "SASL" .Values.cluster.listeners.interbroker.protocol) }}'
            value: '{{ .Values.cluster.listeners.interbroker.saslMechanism }}'
          KAFKA_SASL_OAUTHBEARER_JWKS_ENDPOINT_URL:
            enabled: '{{ and .Values.auth.enabled (contains "OAUTHBEARER" .Values.auth.sasl.enabledMechanisms) }}'
            value: '{{ .Values.auth.sasl.oauthbearer.jwksEndpointUrl }}'
          KAFKA_SASL_OAUTHBEARER_TOKEN_ENDPOINT_URL:
            enabled: '{{ and .Values.auth.enabled (contains "OAUTHBEARER" .Values.auth.sasl.enabledMechanisms) }}'
            value: '{{ .Values.auth.sasl.oauthbearer.tokenEndpointUrl }}'
          KAFKA_SASL_KERBEROS_SERVICE_NAME:
            enabled: '{{ and .Values.auth.enabled (contains "GSSAPI" .Values.auth.sasl.enabledMechanisms) }}'
            value: '{{ include "renderServiceName" (dict "nodeType" "controller" "context" $) }}'
          # SSL configuration
          KAFKA_SSL_ENDPOINT_IDENTIFICATION_ALGORITHM:
            enabled: '{{ and .Values.tls.enabled (not .Values.tls.hostnameVerification) }}'
            value: ""
          KAFKA_SSL_CLIENT_AUTH: 
            enabled: '{{ .Values.tls.enabled }}'
            value: '{{ .Values.tls.clientAuth }}'
          KAFKA_SSL_KEYSTORE_LOCATION:
            enabled: '{{ and .Values.tls.enabled }}'
            value: '{{ printf "%s/%s.keystore.jks" .Values.controller.podTemplates.containers.controller.volumeMounts.certs.mountPath "$(_KAFKA_POD_HOSTNAME)" }}'
          KAFKA_SSL_KEYSTORE_PASSWORD:
            enabled: '{{ and .Values.tls.enabled (eq .Values.tls.format "JKS") (not (empty .Values.tls.keystorePassword)) }}'
            value: '{{ .Values.tls.keystorePassword }}'
          KAFKA_SSL_TRUSTSTORE_LOCATION:
            enabled: '{{ and .Values.tls.enabled }}'
            value: '{{ printf "%s/%s" .Values.controller.podTemplates.containers.controller.volumeMounts.certs.mountPath .Values.tls.truststoreFilename }}'
          KAFKA_SSL_TRUSTSTORE_PASSWORD:
            enabled: '{{ and .Values.tls.enabled (eq .Values.tls.format "JKS") (not (empty .Values.tls.truststorePassword)) }}'
            value: '{{ .Values.tls.truststorePassword }}'
          KAFKA_SSL_KEY_PASSWORD:
            enabled: '{{ and .Values.tls.enabled (not (empty .Values.tls.keystoreKeyPassword)) }}'
            value: '{{ .Values.tls.keystoreKeyPassword }}'
          KAFKA_SSL_KEYSTORE_KEY:
            enabled: '{{ and .Values.tls.enabled (eq .Values.tls.format "PEM") (not (eq .Values.tls.clientAuth "none")) }}'
            value: '{{ include "fileToMultilineString" (dict "file" (printf "%s/%s.key" .Values.controller.podTemplates.containers.controller.volumeMounts.certs.mountPath "$(_KAFKA_POD_HOSTNAME)") "context" $) }}'
          KAFKA_SSL_KEYSTORE_CERTIFICATE_CHAIN:
            enabled: '{{ and .Values.tls.enabled (eq .Values.tls.format "PEM") }}'
            value: '{{ include "fileToMultilineString" (dict "file" (printf "%s/%s.crt" .Values.controller.podTemplates.containers.controller.volumeMounts.certs.mountPath "$(_KAFKA_POD_HOSTNAME)") "context" $) }}'
          KAFKA_SSL_TRUSTORE_CERTIFICATES:
            enabled: '{{ and .Values.tls.enabled (eq .Values.tls.format "PEM") }}'
            value: '{{ include "fileToMultilineString" (dict "file" (printf "%s/%s" .Values.controller.podTemplates.containers.controller.volumeMounts.certs.mountPath (ternary (printf "%s.crt" "$(_KAFKA_POD_HOSTNAME)") .Values.tls.caCertFilename (empty .Values.tls.caCertFilename))) "context" $) }}'
        # -- List of sources from which to populate environment variables to the Apache Kafka container (e.g. a ConfigMaps or a Secret)
        envFrom: []
        # -- Volume mount templates for the Apache Kafka container, templates are allowed in all fields
        # @default -- See `values.yaml`
        # Each field has the volume mount name as key, and a YAML string template with the values; you must set `enabled: true` to enable it
        volumeMounts:
          conf:
            enabled: '{{ eq (include "templateToBoolean" (dict "template" .Values.controller.configMap.enabled "context" $)) "true" }}'
            mountPath: /mnt/kafka/config
            readOnly: true
          data:
            enabled: true
            mountPath: /mnt/kafka/data
          scripts:
            enabled: true
            mountPath: /mnt/kafka/scripts
            readOnly: true
          certs:
            enabled: '{{ .Values.tls.enabled }}'
            mountPath: /mnt/kafka/certs
            readOnly: true
          sasl:
            enabled: '{{ and .Values.auth.enabled (contains "GSSAPI" .Values.auth.sasl.enabledMechanisms) }}'
            mountPath: /mnt/kafka/sasl
            readOnly: true
          logs:
            enabled: true
            volumeCount: '{{ .Values.cluster.disksPerBroker }}'
            mountPath: /mnt/kafka/logs
        # -- Custom resource requirements for the Apache Kafka container
        resources: {}
        # We usually recommend not to specify default resources and to leave this as a conscious
        # choice for the user. This also increases chances charts run on environments with little
        # resources, such as Minikube. If you do want to specify resources, uncomment the following
        # lines, adjust them as necessary, and remove the curly braces after 'resources:'
        #   limits:
        #    cpu: 100m
        #    memory: 128Mi
        #   requests:
        #    cpu: 100m
        #    memory: 128Mi
        # -- Security context override for the Apache Kafka container (if set, `containerSecurityContext.*` values will be ignored for this container)
        securityContext: {}
        livenessProbe:
          # -- Enable liveness probe for Apache Kafka
          enabled: true
          # -- Command to execute for the Apache Kafka startup probe
          # @default -- See `values.yaml`
          tcpSocket:
            port: controller
          # -- Number of seconds after the Apache Kafka container has started before liveness probes are initiated
          initialDelaySeconds: 45
          # -- How often (in seconds) to perform the Apache Kafka liveness probe
          periodSeconds: 15
          # -- Number of seconds after which the Apache Kafka liveness probe times out
          timeoutSeconds: 5
          # -- Minimum consecutive failures for the Apache Kafka liveness probe to be considered failed after having succeeded
          failureThreshold: 5
          # -- Minimum consecutive successes for the Apache Kafka liveness probe to be considered successful after having failed
          successThreshold: 1
        readinessProbe:
          # -- Enable readiness probe for Apache Kafka
          enabled: true
          # -- Command to execute for the Apache Kafka startup probe
          # @default -- See `values.yaml`
          exec:
            command:
              - /mnt/kafka/scripts/apache-kafka-readiness-check.sh
          # -- Number of seconds after the Apache Kafka container has started before readiness probes are initiated
          initialDelaySeconds: 30
          # -- How often (in seconds) to perform the Apache Kafka readiness probe
          periodSeconds: 15
          # -- Number of seconds after which the Apache Kafka readiness probe times out
          timeoutSeconds: 5
          # -- Minimum consecutive failures for the Apache Kafka readiness probe to be considered failed after having succeeded
          failureThreshold: 5
          # -- Minimum consecutive successes for the Apache Kafka readiness probe to be considered successful after having failed
          successThreshold: 1
        startupProbe:
          # -- Enable startup probe for Apache Kafka
          enabled: false
          # -- Port number used to check if the Apache Kafka service is alive
          # @default -- See `values.yaml`
          tcpSocket:
            port: controller
          # -- Number of seconds after the Apache Kafka container has started before startup probes are initiated
          initialDelaySeconds: 0
          # -- How often (in seconds) to perform the Apache Kafka startup probe
          periodSeconds: 15
          # -- Number of seconds after which the Apache Kafka startup probe times out
          timeoutSeconds: 5
          # -- Minimum consecutive failures for the Apache Kafka startup probe to be considered failed after having succeeded
          failureThreshold: 10
          # -- Minimum consecutive successes for the Apache Kafka startup probe to be considered successful after having failed
          successThreshold: 1
        # -- Custom attributes for the Apache Kafka container (see [`Container` API spec](https://kubernetes.io/docs/reference/kubernetes-api/workload-resources/pod-v1/#Container))
        "*":
        # Note: This field is only added for documentation purposes
    # -- Custom pull secrets for the Apache Kafka container in the PodTemplate
    imagePullSecrets: []
    # -- Volume templates for the Apache Kafka PodTemplate, templates are allowed in all fields
    # @default -- See `values.yaml`
    # Each field has the volume name as key, and a YAML string template with the values; you must set `enabled: true` to enable it
    volumes:
      conf:
        enabled: '{{ eq (include "templateToBoolean" (dict "template" .Values.controller.configMap.enabled "context" $)) "true" }}'
        configMap:
          name: '{{ include "fullName" (dict "suffix" "controller" "context" $) }}'
      data:
        enabled: '{{ and (not .Values.controller.statefulset.volumeClaimTemplates) (not .Values.persistence.enabled) }}'
        emptyDir:
          medium: ""
      scripts:
        enabled: true
        configMap:
          name: '{{ include "fullName" (dict "suffix" "controller-scripts" "context" $) }}'
          defaultMode: 0o550
      certs:
        enabled: '{{ .Values.tls.enabled }}'
        secret:
          secretName: '{{ tpl .Values.tls.existingSecret . }}'
          defaultMode: 0o400
      sasl:
        enabled: '{{ and .Values.auth.enabled (contains "GSSAPI" .Values.auth.sasl.enabledMechanisms) }}'
        secret:
          secretName: '{{ tpl .Values.auth.sasl.gssapi.existingSecret . }}'
          defaultMode: 0o400
      logs:
        enabled: '{{ and (not .Values.controller.statefulset.volumeClaimTemplates) (not .Values.persistence.enabled) }}'
        volumeCount: '{{ int .Values.cluster.disksPerBroker }}'
        emptyDir:
          medium: ""
    # -- Service account name override for the pods in the Apache Kafka PodTemplate (if set, `serviceAccount.name` will be ignored)
    serviceAccountName: ""
    # -- Security context override for the pods in the Apache Kafka PodTemplate (if set, `podSecurityContext.*` values will be ignored)
    securityContext: {}
    # -- Custom attributes for the pods in the Apache Kafka PodTemplate (see [`PodSpec` API reference](https://kubernetes.io/docs/reference/kubernetes-api/workload-resources/pod-v1/#PodSpec))
    "*":
    # Note: This field is only added for documentation purposes

  service:
    # -- Create a service for Apache Kafka (apart from the headless service)
    enabled: true
    # -- Custom annotations to add to the service for Apache Kafka
    annotations: {}
    # -- Apache Kafka service type
    type: ClusterIP
    # Apache Kafka service nodePort values
    nodePorts:
      # -- (int32) Service nodePort override for Apache Kafka client connections
      client: ""
      # -- (int32) Service nodePort override for Apache Kafka controller connections
      controller: ""
      # -- (int32) Service nodePort override for Apache Kafka interbroker connections
      interbroker: ""
      # -- (int32) Service nodePort override for custom Apache Kafka ports specified in `containerPorts.*`
      "*":
      # Note: This field is only added for documentation purposes
    # Service port values
    ports:
      # -- (int32) Service port override for Apache Kafka client connections
      client: ""
      # -- (int32) Apache Kafka port number for controller connections
      controller: ""
      # -- (int32) Apache Kafka port number for interbroker connections
      interbroker: ""
      # -- (int32) Service port override for custom Apache Kafka ports specified in `containerPorts.*`
      "*":
      # Note: This field is only added for documentation purposes
    # -- Custom attributes for the Apache Kafka service (see [`ServiceSpec` API reference](https://kubernetes.io/docs/reference/kubernetes-api/service-resources/service-v1/#ServiceSpec))
    "*":
    # Note: This field is only added for documentation purposes

  headlessService:
    # -- Custom annotations to add to the headless service for Apache Kafka
    annotations: {}
    # -- Apache Kafka headless service type
    type: ClusterIP
    # IP address of the service
    # When clusterIP is "None", no virtual IP is allocated and the endpoints are published as a set of endpoints rather than a virtual IP
    clusterIP: None
    # -- Disregard indications of ready/not-ready
    # The primary use case for setting this field is for a StatefulSet's Headless Service to propagate SRV DNS records for its Pods for the purpose of peer discovery
    publishNotReadyAddresses: true
    # Headless service port values
    ports:
      # -- (int32) Headless service port override for Apache Kafka client connections
      client: ""
      # -- (int32) Apache Kafka port number for controller connections
      controller: ""
      # -- (int32) Apache Kafka port number for interbroker connections
      interbroker: ""
      # -- (int32) Headless service port override for custom Apache Kafka ports specified in `containerPorts.*`
      "*":
      # Note: This field is only added for documentation purposes
    # -- Custom attributes for the Apache Kafka headless service (see [`ServiceSpec` API reference](https://kubernetes.io/docs/reference/kubernetes-api/service-resources/service-v1/#ServiceSpec))
    "*":
    # Note: This field is only added for documentation purposes

broker:
  # -- Whether to deploy broker-only nodes
  enabled: false
  # -- Java heapOpts
  heapOpts: "-Xms512M -Xmx512M"
  # -- Configuration file name for the brokers' server properties in the config map
  configurationFile: server.properties
  # -- Extra configurations to add to the controller configuration file. Can be defined as a string, a key-value (string-string) map, or an array of entries.
  configuration: ""
  # -- Name of an existing config map for extra configurations to add to the Apache Kafka configuration file
  existingConfigMap: ""
  # -- ConfigMaps to deploy
  # @default -- See `values.yaml`
  configMap:
    # -- Create a config map for Apache Kafka configuration
    enabled: '{{ and (not .Values.broker.existingConfigMap) (not (empty .Values.broker.configuration)) }}'
    # See: https://kafka.apache.org/documentation/#configuration
    '{{ .Values.broker.configurationFile }}': '{{ tpl (include "configuration" (dict "values" .Values.broker.configuration "context" $)) . }}'
    # -- (string) Custom configuration file to include, templates are allowed both in the config map name and contents
    "*":
    # Note: This field is only added for documentation purposes
  # -- Secrets to deploy
  # @default -- See `values.yaml`
  secret:
    # -- Create a secret for Apache Kafka credentials
    # @default -- `true` if authentication is enabled without existing secret, `false` otherwise
    enabled: '{{ and (eq (include "auth.enabled" .) "true") (not .Values.auth.existingSecret) }}'
    '{{ include "auth.passwordKey" . }}': '{{ default (randAlphaNum 16) .Values.auth.password }}'
    # -- (string) Custom secret to include, templates are allowed both in the secret name and contents
    "*":
    # Note: This field is only added for documentation purposes

  statefulset:
    # -- Enable the StatefulSet template for Apache Kafka standalone brokers
    enabled: true
    # -- Override for the Apache Kafka' StatefulSet serviceName field, it will be autogenerated if unset
    serviceName: ""
    # -- Template to use for all pods created by the Apache Kafka StatefulSet (overrides `podTemplates.*`)
    template: {}
    # -- Desired number of PodTemplate replicas for Apache Kafka broker (overrides `cluster.nodeCount.broker`)
    replicas: ""
    # -- Strategy that will be employed to update the pods in the Apache Kafka StatefulSet
    # @default -- See `values.yaml`
    updateStrategy:
      type: RollingUpdate
    # -- How Apache Kafka pods are created during the initial scaleup
    podManagementPolicy: Parallel
    # -- Lifecycle of the persistent volume claims created from Apache Kafka volumeClaimTemplates
    persistentVolumeClaimRetentionPolicy: {}
    #  whenScaled: Retain
    #  whenDeleted: Retain
    # -- Volume claim templates for the Apache Kafka statefulset, templates are allowed in all fields
    # @default -- See `values.yaml`
    # Each field has the volumeClaimTemplate name as key, and a YAML string template with the values; you must set `enabled: true` to enable it
    volumeClaimTemplates:
      data:
        enabled: '{{ .Values.persistence.enabled }}'
      logs:
        enabled: '{{ .Values.persistence.enabled }}'
        volumeCount: '{{ int .Values.cluster.disksPerBroker }}'
    # -- Custom attributes for the Apache Kafka StatefulSet (see [`StatefulSetSpec` API reference](https://kubernetes.io/docs/reference/kubernetes-api/workload-resources/stateful-set-v1/#StatefulSetSpec))
    "*":
    # Note: This field is only added for documentation purposes

  podTemplates:
    # -- Annotations to add to all pods in the Apache Kafka StatefulSet's PodTemplate
    # @default -- See `values.yaml`
    annotations:
      kubectl.kubernetes.io/default-container: broker
    # -- Labels to add to all pods in the Apache Kafka StatefulSet's PodTemplate
    labels: {}
    # -- Number of seconds prior to the container being forcibly terminated when marked for deletion or restarted.
    terminationGracePeriodSeconds: 120
    # -- Init containers to deploy in the Apache Kafka PodTemplate
    # @default -- See `values.yaml`
    # Each field has the init container name as key, and a YAML object template with the values; you must set `enabled: true` to enable it
    initContainers:
      volume-permissions:
        # -- Enable the volume-permissions init container in the Apache Kafka PodTemplate
        enabled: false
        # -- Image override for the Apache Kafka volume-permissions init container (if set, `images.volume-permissions.{name,tag,digest}` values will be ignored for this container)
        image: ""
        # -- Image pull policy override for the Apache Kafka volume-permissions init container (if set `images.volume-permissions.pullPolicy` values will be ignored for this container)
        imagePullPolicy: ""
        # -- Entrypoint override for the Apache Kafka volume-permissions container
        # @default -- See `values.yaml`
        command:
          - /bin/sh
          - -ec
          - |
            chown -R {{ .Values.containerSecurityContext.runAsUser }}:{{ .Values.podSecurityContext.fsGroup }} /mnt/kafka/data
        # -- Arguments override for the Apache Kafka volume-permissions init container entrypoint
        args: []
        # -- Object with the environment variables templates to use in the Apache Kafka volume-permissions init container, the values can be specified as an object or a string; when using objects you must also set `enabled: true` to enable it
        # @default -- No environment variables are set
        env: {}
        # -- List of sources from which to populate environment variables to the Apache Kafka volume-permissions init container (e.g. a ConfigMaps or a Secret)
        envFrom: []
        # -- Custom volume mounts for the Apache Kafka volume-permissions init container, templates are allowed in all fields
        # @default -- See `values.yaml`
        # Each field has the volume mount name as key, and a YAML string template with the values; you must set `enabled: true` to enable it
        volumeMounts:
          data:
            enabled: true
            mountPath: /mnt/kafka/data
        # -- Apache Kafka init-containers resource requirements
        resources: {}
        # We usually recommend not to specify default resources and to leave this as a conscious
        # choice for the user. This also increases chances charts run on environments with little
        # resources, such as Minikube. If you do want to specify resources, uncomment the following
        # lines, adjust them as necessary, and remove the curly braces after 'resources:'
        #   limits:
        #    cpu: 100m
        #    memory: 128Mi
        #   requests:
        #    cpu: 100m
        #    memory: 128Mi
        # -- Security context override for the Apache Kafka volume-permissions init container (if set, `containerSecurityContext.*` values will be ignored for this container)
        # @default -- See `values.yaml`
        securityContext:
          runAsUser: 0
        # -- Custom attributes for the Apache Kafka volume-permissions init container (see [`Container` API spec](https://kubernetes.io/docs/reference/kubernetes-api/workload-resources/pod-v1/#Container))
        "*":
        # Note: This field is only added for documentation purposes
    # -- Containers to deploy in the Apache Kafka PodTemplate
    # @default -- See `values.yaml`
    # Each field has the container name as key, and a YAML object template with the values; you must set `enabled: true` to enable it
    containers:
      broker:
        # -- Enable the Apache Kafka container in the PodTemplate
        enabled: true
        # -- Image override for the Apache Kafka container (if set, `images.broker.{name,tag,digest}` values will be ignored for this container)
        image: ""
        # -- Image pull policy override for the Apache Kafka container (if set `images.broker.pullPolicy` values will be ignored for this container)
        imagePullPolicy: ""
        # -- Entrypoint override for the Apache Kafka container
        # @default -- See `values.yaml`
        command:
          - /bin/bash
          - -ec
          - |
            exec /mnt/kafka/scripts/apache-kafka-entrypoint.sh
        # -- Arguments override for the Apache Kafka container entrypoint
        args: []
        # -- Ports override for the Apache Kafka container (if set, `containerPorts.*` values will be ignored for this container)
        ports: {}
        # -- Object with the environment variables templates to use in the Apache Kafka container, the values can be specified as an object or a string; when using objects you must also set `enabled: true` to enable it
        # @default -- See `values.yaml`
        env:
          # Aux environment variables to be used in the init script
          _KAFKA_POD_HOSTNAME:
            enabled: true
            valueFrom:
              fieldRef:
                fieldPath: metadata.name
          _KAFKA_MIN_BROKER_ID: '{{ default 0 .Values.cluster.minBrokerID }}'
          # Aux environment variables to be used in the heathcheck config
          _KAFKA__HEALTHCHECK_PROPERTIES_FILE: '/usr/share/kafka/config/healthcheck.properties'
          _KAFKA_HEALTHCHECK_SECURITY_PROTOCOL: '{{ .Values.cluster.listeners.client.protocol }}'
          _KAFKA_HEALTHCHECK_SASL_JAAS_CONFIG:
            enabled: '{{ and .Values.auth.enabled (contains "SASL" .Values.cluster.listeners.client.protocol) }}'
            value: '{{ include "jaasConfigValue" (dict "listener" .Values.cluster.listeners.client "listenerType" "broker_healthcheck" "nodeType" "broker" "hostname" "$(_KAFKA_POD_HOSTNAME)" "context" $) }}'
          _KAFKA_HEALTHCHECK_SASL_MECHANISM:
            enabled: '{{ and .Values.auth.enabled (contains "SASL" .Values.cluster.listeners.client.protocol) }}'
            value: '{{ .Values.cluster.listeners.client.saslMechanism }}'
          _KAFKA_HEALTHCHECK_SSL_KEYSTORE_LOCATION:
            enabled: '{{ and .Values.tls.enabled (not (eq .Values.tls.clientAuth "none")) }}'
            value: '{{ printf "%s/%s.keystore.jks" .Values.broker.podTemplates.containers.broker.volumeMounts.certs.mountPath "$(_KAFKA_POD_HOSTNAME)" }}'
          _KAFKA_HEALTHCHECK_SSL_KEYSTORE_PASSWORD:
            enabled: '{{ and .Values.tls.enabled (eq .Values.tls.format "JKS") (not (empty .Values.tls.keystorePassword)) (not (eq .Values.tls.clientAuth "none")) }}'
            value: '{{ .Values.tls.keystorePassword }}'
          _KAFKA_HEALTHCHECK_SSL_TRUSTSTORE_LOCATION:
            enabled: '{{ .Values.tls.enabled }}'
            value: '{{ printf "%s/%s" .Values.broker.podTemplates.containers.broker.volumeMounts.certs.mountPath .Values.tls.truststoreFilename }}'
          _KAFKA_HEALTHCHECK_SSL_TRUSTSTORE_PASSWORD:
            enabled: '{{ and .Values.tls.enabled (eq .Values.tls.format "JKS") (not (empty .Values.tls.truststorePassword)) }}'
            value: '{{ .Values.tls.truststorePassword }}'
          _KAFKA_HEALTHCHECK_SSL_KEY_PASSWORD:
            enabled: '{{ and .Values.tls.enabled (not (empty .Values.tls.keystoreKeyPassword)) (not (eq .Values.tls.clientAuth "none")) }}'
            value: '{{ .Values.tls.keystoreKeyPassword }}'
          _KAFKA_HEALTHCHECK_SSL_ENDPOINT_IDENTIFICATION_ALGORITHM:
            enabled: '{{ and .Values.tls.enabled (not .Values.tls.hostnameVerification) }}'
            value: ""
          _KAFKA_HEALTHCHECK_SSL_KEYSTORE_KEY:
            enabled: '{{ and .Values.tls.enabled (eq .Values.tls.format "PEM") (not (eq .Values.tls.clientAuth "none")) }}'
            value: '{{ include "fileToMultilineString" (dict "file" (printf "%s/%s.key" .Values.broker.podTemplates.containers.broker.volumeMounts.certs.mountPath "$(_KAFKA_POD_HOSTNAME)") "context" $) }}'
          _KAFKA_HEALTHCHECK_SSL_KEYSTORE_CERTIFICATE_CHAIN:
            enabled: '{{ and .Values.tls.enabled (eq .Values.tls.format "PEM") }}'
            value: '{{ include "fileToMultilineString" (dict "file" (printf "%s/%s.crt" .Values.broker.podTemplates.containers.broker.volumeMounts.certs.mountPath "$(_KAFKA_POD_HOSTNAME)") "context" $) }}'
          _KAFKA_HEALTHCHECK_SSL_TRUSTORE_CERTIFICATES:
            enabled: '{{ and .Values.tls.enabled (eq .Values.tls.format "PEM") }}'
            value: '{{ include "fileToMultilineString" (dict "file" (printf "%s/%s" .Values.broker.podTemplates.containers.broker.volumeMounts.certs.mountPath (ternary (printf "%s.crt" "$(_KAFKA_POD_HOSTNAME)") .Values.tls.caCertFilename (empty .Values.tls.caCertFilename))) "context" $) }}'
          # General configuration
          KAFKA_PROCESS_ROLES: 'broker'        
          KAFKA_CONTROLLER_QUORUM_VOTERS: '{{ include "quorumVoters" . }}'
          KAFKA_LISTENERS: '{{ include "listeners" (dict "listeners" (list "client" "interbroker") "nodeType" "broker" "hostname" "$(_KAFKA_POD_HOSTNAME)" "context" $) }}'
          KAFKA_ADVERTISED_LISTENERS: '{{ include "listeners" (dict "listeners" (list "client" "interbroker") "nodeType" "broker" "hostname" "$(_KAFKA_POD_HOSTNAME)" "context" $) }}'
          KAFKA_CONTROLLER_LISTENER_NAMES: '{{ .Values.cluster.listeners.controller.name }}'
          KAFKA_LISTENER_SECURITY_PROTOCOL_MAP: 'CONTROLLER:PLAINTEXT,CLIENT:PLAINTEXT,INTERBROKER:PLAINTEXT'
          KAFKA_INTER_BROKER_LISTENER_NAME: '{{ .Values.cluster.listeners.interbroker.name }}'
          KAFKA_LOG_DIRS: '{{ include "logDirs" (dict "mountPath" .Values.broker.podTemplates.containers.broker.volumeMounts.logs.mountPath "context" $) }}'
          KAFKA_OFFSETS_TOPIC_REPLICATION_FACTOR:
            enabled: '{{ not (empty .Values.cluster.offsetsTopicReplicationFactor) }}'
            value: '{{ int .Values.cluster.offsetsTopicReplicationFactor }}'
          KAFKA_NUM_PARTITIONS:
            enabled: '{{ not (empty .Values.cluster.numPartitions) }}'
            value: '{{ int .Values.cluster.numPartitions }}'
          KAFKA_HEAP_OPTS:
            enabled: '{{ not (empty .Values.broker.heapOpts) }}'
            value: '{{ .Values.broker.heapOpts }}'
          CLUSTER_ID:
            enabled: true
            valueFrom:
              configMapKeyRef:
                name: '{{ coalesce .Values.cluster.existingConfigMap (include "fullName" (dict "suffix" "cluster" "context" $)) }}'
                key: '{{ .Values.cluster.clusterIDKey }}'
          KAFKA_LISTENER_SECURITY_PROTOCOL_MAP: '{{ include "protocolMap" . }}'
          # SASL configuration
          KAFKA_SASL_MECHANISM_CONTROLLER_PROTOCOL:
            enabled: '{{ and .Values.auth.enabled (contains "SASL" .Values.cluster.listeners.controller.protocol) }}'
            value: '{{ .Values.cluster.listeners.controller.saslMechanism }}'
          KAFKA_SASL_MECHANISM_INTER_BROKER_PROTOCOL:
            enabled: '{{ and .Values.auth.enabled (contains "SASL" .Values.cluster.listeners.interbroker.protocol) }}'
            value: '{{ .Values.cluster.listeners.interbroker.saslMechanism }}'
          KAFKA_SASL_ENABLED_MECHANISMS:
            enabled: '{{ .Values.auth.enabled }}'
            value: '{{ .Values.auth.sasl.enabledMechanisms }}'
          '{{ include "jaasConfigKey" (dict "listener" .Values.cluster.listeners.client "context" $) }}':
            enabled: '{{ and .Values.auth.enabled (contains "SASL" .Values.cluster.listeners.client.protocol) }}'
            value: '{{ include "jaasConfigValue" (dict "listener" .Values.cluster.listeners.client "listenerType" "client" "nodeType" "broker" "hostname" "$(_KAFKA_POD_HOSTNAME)" "context" $) }}'
          '{{ include "jaasConfigKey" (dict "listener" .Values.cluster.listeners.controller "context" $) }}':
            enabled: '{{ and .Values.auth.enabled (contains "SASL" .Values.cluster.listeners.controller.protocol) }}'
            value: '{{ include "jaasConfigValue" (dict "listener" .Values.cluster.listeners.controller "listenerType" "controller" "nodeType" "broker" "hostname" "$(_KAFKA_POD_HOSTNAME)" "context" $) }}'
          '{{ include "jaasConfigKey" (dict "listener" .Values.cluster.listeners.interbroker "context" $) }}':
            enabled: '{{ and .Values.auth.enabled (contains "SASL" .Values.cluster.listeners.interbroker.protocol) }}'
            value: '{{ include "jaasConfigValue" (dict "listener" .Values.cluster.listeners.interbroker "listenerType" "interbroker" "nodeType" "broker" "hostname" "$(_KAFKA_POD_HOSTNAME)" "context" $) }}'
          '{{ printf "%s_%s_%s" "KAFKA_LISTENER_NAME" .Values.cluster.listeners.client.name "SASL_ENABLED_MECHANISMS" }}':
            enabled: '{{ and .Values.auth.enabled (contains "SASL" .Values.cluster.listeners.client.protocol) }}'
            value: '{{ .Values.cluster.listeners.client.saslMechanism }}'
          '{{ printf "%s_%s_%s" "KAFKA_LISTENER_NAME" .Values.cluster.listeners.interbroker.name "SASL_ENABLED_MECHANISMS" }}':
            enabled: '{{ and .Values.auth.enabled (contains "SASL" .Values.cluster.listeners.interbroker.protocol) }}'
            value: '{{ .Values.cluster.listeners.interbroker.saslMechanism }}'
          KAFKA_SASL_OAUTHBEARER_JWKS_ENDPOINT_URL:
            enabled: '{{ and .Values.auth.enabled (contains "OAUTHBEARER" .Values.auth.sasl.enabledMechanisms) }}'
            value: '{{ .Values.auth.sasl.oauthbearer.jwksEndpointUrl }}'
          KAFKA_SASL_OAUTHBEARER_TOKEN_ENDPOINT_URL:
            enabled: '{{ and .Values.auth.enabled (contains "OAUTHBEARER" .Values.auth.sasl.enabledMechanisms) }}'
            value: '{{ .Values.auth.sasl.oauthbearer.tokenEndpointUrl }}'
          KAFKA_SASL_KERBEROS_SERVICE_NAME:
            enabled: '{{ and .Values.auth.enabled (contains "GSSAPI" .Values.auth.sasl.enabledMechanisms) }}'
            value: '{{ include "renderServiceName" (dict "nodeType" "broker" "context" $) }}'
          # SSL configuration
          KAFKA_SSL_ENDPOINT_IDENTIFICATION_ALGORITHM:
            enabled: '{{ and .Values.tls.enabled (not .Values.tls.hostnameVerification) }}'
            value: ""
          KAFKA_SSL_CLIENT_AUTH: 
            enabled: '{{ .Values.tls.enabled }}'
            value: '{{ .Values.tls.clientAuth }}'
          KAFKA_SSL_KEYSTORE_LOCATION:
            enabled: '{{ and .Values.tls.enabled }}'
            value: '{{ printf "%s/%s.keystore.jks" .Values.broker.podTemplates.containers.broker.volumeMounts.certs.mountPath "$(_KAFKA_POD_HOSTNAME)" }}'
          KAFKA_SSL_KEYSTORE_PASSWORD:
            enabled: '{{ and .Values.tls.enabled (eq .Values.tls.format "JKS") (not (empty .Values.tls.keystorePassword)) }}'
            value: '{{ .Values.tls.keystorePassword }}'
          KAFKA_SSL_TRUSTSTORE_LOCATION:
            enabled: '{{ and .Values.tls.enabled }}'
            value: '{{ printf "%s/%s" .Values.broker.podTemplates.containers.broker.volumeMounts.certs.mountPath .Values.tls.truststoreFilename }}'
          KAFKA_SSL_TRUSTSTORE_PASSWORD:
            enabled: '{{ and .Values.tls.enabled (eq .Values.tls.format "JKS") (not (empty .Values.tls.truststorePassword)) }}'
            value: '{{ .Values.tls.truststorePassword }}'
          KAFKA_SSL_KEY_PASSWORD:
            enabled: '{{ and .Values.tls.enabled (not (empty .Values.tls.keystoreKeyPassword)) }}'
            value: '{{ .Values.tls.keystoreKeyPassword }}'
          KAFKA_SSL_KEYSTORE_KEY:
            enabled: '{{ and .Values.tls.enabled (eq .Values.tls.format "PEM") (not (eq .Values.tls.clientAuth "none")) }}'
            value: '{{ include "fileToMultilineString" (dict "file" (printf "%s/%s.key" .Values.broker.podTemplates.containers.broker.volumeMounts.certs.mountPath "$(_KAFKA_POD_HOSTNAME)") "context" $) }}'
          KAFKA_SSL_KEYSTORE_CERTIFICATE_CHAIN:
            enabled: '{{ and .Values.tls.enabled (eq .Values.tls.format "PEM") }}'
            value: '{{ include "fileToMultilineString" (dict "file" (printf "%s/%s.crt" .Values.broker.podTemplates.containers.broker.volumeMounts.certs.mountPath "$(_KAFKA_POD_HOSTNAME)") "context" $) }}'
          KAFKA_SSL_TRUSTORE_CERTIFICATES:
            enabled: '{{ and .Values.tls.enabled (eq .Values.tls.format "PEM") }}'
            value: '{{ include "fileToMultilineString" (dict "file" (printf "%s/%s" .Values.broker.podTemplates.containers.broker.volumeMounts.certs.mountPath (ternary (printf "%s.crt" "$(_KAFKA_POD_HOSTNAME)") .Values.tls.caCertFilename (empty .Values.tls.caCertFilename))) "context" $) }}'
        # -- List of sources from which to populate environment variables to the Apache Kafka container (e.g. a ConfigMaps or a Secret)
        envFrom: []
        # -- Volume mount templates for the Apache Kafka container, templates are allowed in all fields
        # @default -- See `values.yaml`
        # Each field has the volume mount name as key, and a YAML string template with the values; you must set `enabled: true` to enable it
        volumeMounts:
          conf:
            enabled: '{{ eq (include "templateToBoolean" (dict "template" .Values.broker.configMap.enabled "context" $)) "true" }}'
            mountPath: /mnt/kafka/config
            readOnly: true
          data:
            enabled: true
            mountPath: /mnt/kafka/data
          scripts:
            enabled: true
            mountPath: /mnt/kafka/scripts
            readOnly: true
          certs:
            enabled: '{{ .Values.tls.enabled }}'
            mountPath: /mnt/kafka/certs
            readOnly: true
          sasl:
            enabled: '{{ and .Values.auth.enabled (contains "GSSAPI" .Values.auth.sasl.enabledMechanisms) }}'
            mountPath: /mnt/kafka/sasl
            readOnly: true
          logs:
            enabled: true
            volumeCount: '{{ .Values.cluster.disksPerBroker }}'
            mountPath: /mnt/kafka/logs
        # -- Custom resource requirements for the Apache Kafka container
        resources: {}
        # We usually recommend not to specify default resources and to leave this as a conscious
        # choice for the user. This also increases chances charts run on environments with little
        # resources, such as Minikube. If you do want to specify resources, uncomment the following
        # lines, adjust them as necessary, and remove the curly braces after 'resources:'
        #   limits:
        #    cpu: 100m
        #    memory: 128Mi
        #   requests:
        #    cpu: 100m
        #    memory: 128Mi
        # -- Security context override for the Apache Kafka container (if set, `containerSecurityContext.*` values will be ignored for this container)
        securityContext: {}
        livenessProbe:
          # -- Enable liveness probe for Apache Kafka
          enabled: true
          # -- Command to execute for the Apache Kafka startup probe
          # @default -- See `values.yaml`
          tcpSocket:
            port: client
          # -- Number of seconds after the Apache Kafka container has started before liveness probes are initiated
          initialDelaySeconds: 45
          # -- How often (in seconds) to perform the Apache Kafka liveness probe
          periodSeconds: 15
          # -- Number of seconds after which the Apache Kafka liveness probe times out
          timeoutSeconds: 5
          # -- Minimum consecutive failures for the Apache Kafka liveness probe to be considered failed after having succeeded
          failureThreshold: 5
          # -- Minimum consecutive successes for the Apache Kafka liveness probe to be considered successful after having failed
          successThreshold: 1
        readinessProbe:
          # -- Enable readiness probe for Apache Kafka
          enabled: true
          # -- Command to execute for the Apache Kafka startup probe
          # @default -- See `values.yaml`
          exec:
            command:
              - /mnt/kafka/scripts/apache-kafka-readiness-check.sh
          # -- Number of seconds after the Apache Kafka container has started before readiness probes are initiated
          initialDelaySeconds: 30
          # -- How often (in seconds) to perform the Apache Kafka readiness probe
          periodSeconds: 15
          # -- Number of seconds after which the Apache Kafka readiness probe times out
          timeoutSeconds: 5
          # -- Minimum consecutive failures for the Apache Kafka readiness probe to be considered failed after having succeeded
          failureThreshold: 5
          # -- Minimum consecutive successes for the Apache Kafka readiness probe to be considered successful after having failed
          successThreshold: 1
        startupProbe:
          # -- Enable startup probe for Apache Kafka
          enabled: false
          # -- Port number used to check if the Apache Kafka service is alive
          # @default -- See `values.yaml`
          tcpSocket:
            port: client
          # -- Number of seconds after the Apache Kafka container has started before startup probes are initiated
          initialDelaySeconds: 0
          # -- How often (in seconds) to perform the Apache Kafka startup probe
          periodSeconds: 10
          # -- Number of seconds after which the Apache Kafka startup probe times out
          timeoutSeconds: 5
          # -- Minimum consecutive failures for the Apache Kafka startup probe to be considered failed after having succeeded
          failureThreshold: 10
          # -- Minimum consecutive successes for the Apache Kafka startup probe to be considered successful after having failed
          successThreshold: 1
        # -- Custom attributes for the Apache Kafka container (see [`Container` API spec](https://kubernetes.io/docs/reference/kubernetes-api/workload-resources/pod-v1/#Container))
        "*":
        # Note: This field is only added for documentation purposes
    # -- Custom pull secrets for the Apache Kafka container in the PodTemplate
    imagePullSecrets: []
    # -- Volume templates for the Apache Kafka PodTemplate, templates are allowed in all fields
    # @default -- See `values.yaml`
    # Each field has the volume name as key, and a YAML string template with the values; you must set `enabled: true` to enable it
    volumes:
      conf:
        enabled: '{{ eq (include "templateToBoolean" (dict "template" .Values.broker.configMap.enabled "context" $)) "true" }}'
        configMap:
          name: '{{ include "fullName" (dict "suffix" "broker" "context" $) }}'
      data:
        enabled: '{{ and (not .Values.broker.statefulset.volumeClaimTemplates) (not .Values.persistence.enabled) }}'
        emptyDir:
          medium: ""
      scripts:
        enabled: true
        configMap:
          name: '{{ include "fullName" (dict "suffix" "broker-scripts" "context" $) }}'
          defaultMode: 0o550
      certs:
        enabled: '{{ .Values.tls.enabled }}'
        secret:
          secretName: '{{ tpl .Values.tls.existingSecret . }}'
          defaultMode: 0o400
      sasl:
        enabled: '{{ and .Values.auth.enabled (contains "GSSAPI" .Values.auth.sasl.enabledMechanisms) }}'
        secret:
          secretName: '{{ tpl .Values.auth.sasl.gssapi.existingSecret . }}'
          defaultMode: 0o400
      logs:
        enabled: '{{ and (not .Values.broker.statefulset.volumeClaimTemplates) (not .Values.persistence.enabled) }}'
        volumeCount: '{{ int .Values.cluster.disksPerBroker }}'
        emptyDir:
          medium: ""
    # -- Service account name override for the pods in the Apache Kafka PodTemplate (if set, `serviceAccount.name` will be ignored)
    serviceAccountName: ""
    # -- Security context override for the pods in the Apache Kafka PodTemplate (if set, `podSecurityContext.*` values will be ignored)
    securityContext: {}
    # -- Custom attributes for the pods in the Apache Kafka PodTemplate (see [`PodSpec` API reference](https://kubernetes.io/docs/reference/kubernetes-api/workload-resources/pod-v1/#PodSpec))
    "*":
    # Note: This field is only added for documentation purposes

  service:
    # -- Create a service for Apache Kafka (apart from the headless service)
    enabled: true
    # -- Custom annotations to add to the service for Apache Kafka
    annotations: {}
    # -- Apache Kafka service type
    type: ClusterIP
    # Apache Kafka service nodePort values
    nodePorts:
      # -- (int32) Service nodePort override for Apache Kafka client connections
      client: ""
      # -- (int32) Service nodePort override for Apache Kafka controller connections
      controller: ""
      # -- (int32) Service nodePort override for Apache Kafka interbroker connections
      interbroker: ""
      # -- (int32) Service nodePort override for custom Apache Kafka ports specified in `containerPorts.*`
      "*":
      # Note: This field is only added for documentation purposes
    # Service port values
    ports:
      # -- (int32) Service port override for Apache Kafka client connections
      client: ""
      # -- (int32) Apache Kafka port number for controller connections
      controller: ""
      # -- (int32) Apache Kafka port number for interbroker connections
      interbroker: ""
      # -- (int32) Service port override for custom Apache Kafka ports specified in `containerPorts.*`
      "*":
      # Note: This field is only added for documentation purposes
    # -- Custom attributes for the Apache Kafka service (see [`ServiceSpec` API reference](https://kubernetes.io/docs/reference/kubernetes-api/service-resources/service-v1/#ServiceSpec))
    "*":
    # Note: This field is only added for documentation purposes

  headlessService:
    # -- Custom annotations to add to the headless service for Apache Kafka
    annotations: {}
    # -- Apache Kafka headless service type
    type: ClusterIP
    # IP address of the service
    # When clusterIP is "None", no virtual IP is allocated and the endpoints are published as a set of endpoints rather than a virtual IP
    clusterIP: None
    # -- Disregard indications of ready/not-ready
    # The primary use case for setting this field is for a StatefulSet's Headless Service to propagate SRV DNS records for its Pods for the purpose of peer discovery
    publishNotReadyAddresses: true
    # Headless service port values
    ports:
      # -- (int32) Headless service port override for Apache Kafka client connections
      client: ""
      # -- (int32) Apache Kafka port number for controller connections
      controller: ""
      # -- (int32) Apache Kafka port number for interbroker connections
      interbroker: ""
      # -- (int32) Headless service port override for custom Apache Kafka ports specified in `containerPorts.*`
      "*":
      # Note: This field is only added for documentation purposes
    # -- Custom attributes for the Apache Kafka headless service (see [`ServiceSpec` API reference](https://kubernetes.io/docs/reference/kubernetes-api/service-resources/service-v1/#ServiceSpec))
    "*":
    # Note: This field is only added for documentation purposes

persistence:
  # -- Enable persistent volume claims for Apache Kafka pods
  enabled: true
  # -- Custom annotations to add to the persistent volume claims used by Apache Kafka pods
  annotations: {}
  # -- Custom labels to add to the persistent volume claims used by Apache Kafka pods
  labels: {}
  # -- Name of an existing PersistentVolumeClaim to use by Apache Kafka pods
  existingClaim: ""
  # -- Persistent volume access modes
  accessModes:
    - ReadWriteOnce
  resources:
    requests:
      # -- Size of the persistent volume claim to create for Apache Kafka pods
      storage: 8Gi
  # -- Storage class name to use for the Apache Kafka persistent volume claim
  storageClassName: ""

podSecurityContext:
  # -- Enable pod security context
  enabled: true
  # -- Group ID that will write to persistent volumes
  fsGroup: 1000

containerSecurityContext:
  # -- Enable container security context
  enabled: true
  # -- Allow privilege escalation within containers
  allowPrivilegeEscalation: false
  # -- Run containers as a non-root user
  runAsNonRoot: true
  # -- Which user ID to run the container as
  runAsUser: 1000

networkPolicy:
  # -- Create a NetworkPolicy resource
  enabled: false
  # -- Allow all external connections from and to the pods
  allowExternalConnections: true
  egress:
    # -- Create an egress network policy (requires also `networkPolicy.enabled`)
    enabled: true
    # -- Allow all external egress connections from the pods (requires also `networkPolicy.allowExternalConnections`)
    allowExternalConnections: true
    # -- Custom additional egress rules to enable in the NetworkPolicy resource
    extraRules: []
    # -- List of namespace labels for which to allow egress connections, when external connections are disallowed
    namespaceLabels: {}
    # -- List of pod labels for which to allow egress connections, when external connections are disallowed
    podLabels: {}
    # Network policy port overrides for egress connections
    ports:
      # -- (int32) Network policy port override for Apache Kafka client connections for egress connections
      client: ""
      # -- (int32) Network policy port override for Apache Kafka peer connections for egress connections
      peer: ""
      # -- (int32) Network policy port override for custom ports specified in `containerPorts.*` for egress connections
      "*":
      # Note: This field is only added for documentation purposes
  ingress:
    # -- Create an ingress network policy (requires also `networkPolicy.enabled`)
    enabled: true
    # -- Allow all external ingress connections to the pods (requires also `networkPolicy.allowExternalConnections`)
    allowExternalConnections: true
    # -- List of namespace labels for which to allow ingress connections, when external connections are disallowed
    namespaceLabels: {}
    # -- List of pod labels for which to allow ingress connections, when external connections are disallowed
    podLabels: {}
    # -- Custom additional ingress rules to enable in the NetworkPolicy resource
    extraRules: []
    # Network policy port overrides for ingress connections
    ports:
      # -- (int32) Network policy port override for Apache Kafka client connections for ingress connections
      client: ""
      # -- (int32) Network policy port override for Apache Kafka peer connections for ingress connections
      peer: ""
      # -- (int32) Network policy port override for custom ports specified in `containerPorts.*` for ingress connections
      "*":
      # Note: This field is only added for documentation purposes

podDisruptionBudget:
  # -- Create a pod disruption budget
  enabled: false
  # -- Number of pods from that set that must still be available after the eviction, this option is mutually exclusive with maxUnavailable
  minAvailable: ""
  # -- Number of pods from that can be unavailable after the eviction, this option is mutually exclusive with minAvailable
  maxUnavailable: ""

serviceAccount:
  # -- Create or use an existing service account
  enabled: false
  # -- Add custom annotations to the ServiceAccount
  annotations: {}
  # -- Add custom labels to the ServiceAccount
  labels: {}
  # -- Name of the ServiceAccount to use
  name: ""
  # -- Whether pods running as this service account should have an API token automatically mounted
  automountServiceAccountToken: true
  # -- List of references to secrets in the same namespace to use for pulling any images in pods that reference this ServiceAccount
  imagePullSecrets: []
  # -- List of secrets in the same namespace that pods running using this ServiceAccount are allowed to use
  secrets: []
