routerSpec:
  registry: ${CONTAINER_REGISTRY}
  repository: containers/lmcache-lmstack-router
  tag: 0.1.6-2.33
