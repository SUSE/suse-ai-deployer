# SPDX-License-Identifier: APACHE-2.0
#!BuildTag: charts/vllm:${VERSION}-%RELEASE%
#!BuildTag: charts/vllm:${VERSION}
annotations:
  helm.sh/images: |
    - image: ${CONTAINER_REGISTRY}/containers/vllm-openai:0.9.1-4.18
      name: vllm-openai
    - image: ${CONTAINER_REGISTRY}/containers/lmcache-vllm-openai:0.3.2-3.18
      name: lmcache-vllm-openai
    - image: ${CONTAINER_REGISTRY}/containers/lmcache-lmstack-router:0.1.6-3.20
      name: lmcache-lmstack-router
    - image: ${CONTAINER_REGISTRY}/containers/bci-busybox:15.7-19.10
      name: bci-busybox
  license: Apache-2.0
apiVersion: v2
description: 'A high-throughput and memory-efficient inference and serving engine for LLMs.'
home: https://apps.rancher.io/applications/vllm
icon: https://apps.rancher.io/logos/vllm.png
keywords:
  - ai
  - llm
sources:
  - https://github.com/vllm-project/vllm
name: vllm
type: application
version: ${VERSION}
appVersion: ${APP_VERSION}
maintainers:
  - url: https://www.suse.com/
    name: SUSE LLC
