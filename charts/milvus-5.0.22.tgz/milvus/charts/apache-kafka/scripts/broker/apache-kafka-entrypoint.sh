#!/bin/bash
#
# Entrypoint for Apache Kafka broker pods

# Strict mode
set -euo pipefail

# Load functions used by the script
# shellcheck disable=SC1091
. /mnt/kafka/scripts/functions.sh
# shellcheck disable=SC1091
. /mnt/kafka/scripts/apache-kafka-functions.sh

# KAFKA_NODE_ID must be calculated at runtime
replica_id="${_KAFKA_POD_HOSTNAME##*-}"
broker_id="$((replica_id + _KAFKA_MIN_BROKER_ID))"
export "KAFKA_NODE_ID=$broker_id"

# Create combined PEM keystore and set SSL location vars if PEM format
if [[ -n ${_KAFKA_SSL_CERT_DIR:-} ]]; then
    pem_key="${_KAFKA_SSL_CERT_DIR}/${_KAFKA_POD_HOSTNAME}.key"
    pem_crt="${_KAFKA_SSL_CERT_DIR}/${_KAFKA_POD_HOSTNAME}.crt"
    keystore_pem="/tmp/${_KAFKA_POD_HOSTNAME}-keystore.pem"
    cat "$pem_key" "$pem_crt" >"$keystore_pem"
    export KAFKA_SSL_KEYSTORE_LOCATION="$keystore_pem"
    export _KAFKA_HEALTHCHECK_SSL_KEYSTORE_LOCATION="$keystore_pem"
    truststore_pem="$KAFKA_SSL_TRUSTSTORE_LOCATION_PEM"
    export KAFKA_SSL_TRUSTSTORE_LOCATION="$truststore_pem"
    export _KAFKA_HEALTHCHECK_SSL_TRUSTSTORE_LOCATION="$truststore_pem"
fi

# We need to generate the properties file used needed for the healthcheck
# This is needed specially when TLS/Auth is enabled
envvar_preffix="_KAFKA_HEALTHCHECK_"
for envvar in $(printenv | cut -d '=' -f1 | grep "$envvar_preffix"); do
    kafka_conf_set "$_KAFKA__HEALTHCHECK_PROPERTIES_FILE" \
        "$envvar" "$envvar_preffix"
done

log "Starting Apache Kafka broker server"
exec /etc/kafka/docker/run
