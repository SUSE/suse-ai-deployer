{{/*
    Print true if authentication is enabled, false otherwise.
*/}}
{{- define "application-collection.apache-kafka.auth.enabled" }}
    {{- .Values.auth.enabled }}
{{- end }}

{{- define "application-collection.apache-kafka.configuration" }}
    {{- $context := default . .context }}
    {{- $configuration := .values }}
    {{- $configurationEntries := list }}
    {{- if kindIs "string" $configuration }}
        {{- $configurationEntries = append $configurationEntries (tpl $configuration $) }}
    {{- else if kindIs "array" $configuration }}
        {{- $configurationEntries = concat $configurationEntries (tpl $configuration $) }}
    {{- else }}
        {{- range $configKey, $configValue := $configuration }}
            {{- if not (kindIs "string" $configValue) }}
                {{- if eq (include "application-collection.render.boolean" (dict "template" $configValue.enabled "context" $context)) "true" }}
                    {{- $configurationEntries = append $configurationEntries (printf "%s=%s" (tpl $configKey $context) (tpl $configValue.value $context)) }}
                {{- end }}
            {{- else }}
                {{- $configurationEntries = append $configurationEntries (printf "%s=%s" (tpl $configKey $context) (tpl $configValue $context)) }}
            {{- end }}
        {{- end }}
    {{- end }}
    {{- if $configurationEntries }}
        {{- join "\n" $configurationEntries | nindent 0 }}
    {{- end }}
{{- end }}

{{/*
    Apache Kafka Cluster nodes.
*/}}
{{- define "application-collection.apache-kafka.quorumVoters" }}
    {{- $context := default . .context }}
    {{- $quorumVoters := list }}
    {{- $fullName := include "application-collection.fullName" (dict "suffix" "controller" "context" $context) }}
    {{- $serviceName := coalesce $context.Values.controller.statefulset.serviceName (include "application-collection.fullName" (dict "suffix" (printf "%s-%s" "controller" "headless") "context" $context)) }}
    {{- $releaseNamespace := .Release.Namespace }}
    {{- $clusterDomain := $context.Values.clusterDomain }}
    {{- $port := int (coalesce $context.Values.controller.headlessService.ports.controller $context.Values.containerPorts.controller) }}
    {{- range $node := (until (int (include "application-collection.apache-kafka.nodeCount" (dict "nodeType" "controller" "context" $context)))) }}
        {{- $quorumVoters = append $quorumVoters (printf "%d@%s-%d.%s.%s.svc.%s:%d" $node $fullName $node $serviceName $releaseNamespace $clusterDomain $port) }}
    {{- end }}
    {{- join "," $quorumVoters }}
{{- end }}

{{/*
    Apache Kafka Listeners
*/}}
{{- define "application-collection.apache-kafka.listeners" }}
    {{- $listenerURIs := list }}
    {{- $context := default . .context }}
    {{- $listeners := .listeners }}
    {{- $nodeType := .nodeType }}
    {{- $hostname := default "hostname-placeholder" .hostname }}
    {{- $serviceName := include "application-collection.render.serviceName" (dict "nodeType" $nodeType "context" $context) }}

    {{- range $listener := $listeners }}
        {{- $nodeValues := index $context.Values $nodeType }}
        {{- $headlessServicePorts := $nodeValues.headlessService.ports }}

        {{- $port := int (coalesce (index $headlessServicePorts $listener) (index $context.Values.containerPorts $listener)) }}
        {{- $listenerMap := index $context.Values.cluster.listeners $listener }}
        {{- $podFQDN := include "application-collection.apache-kafka.podFQDN" (dict "hostname" $hostname "serviceName" $serviceName "context" $context) }}
        {{- $listenerURIs = append $listenerURIs (printf "%s://%s:%d" (upper $listenerMap.name) $podFQDN $port) }}
    {{- end }}
    {{- join "," $listenerURIs }}
{{- end }}

{{/*
    Define Apache Kafka log dirs value
*/}}
{{- define "application-collection.apache-kafka.logDirs" }}
    {{- $context := default . .context }}
    {{- $logDir := tpl .logDir $context }}
    {{- $logSubDir := .logSubDir }}
    {{- $disksPerBroker := $context.Values.cluster.disksPerBroker }}
    {{- if $logSubDir }}
        {{- $logDir = printf "%s/%s" $logDir $logSubDir }}
    {{- end }}
    {{- if gt (int $disksPerBroker) 1}}
        {{- $logDirs := list }}
        {{- range $i := until (int $disksPerBroker) }}
            {{- $logDirs = append $logDirs (printf "%s-%d" $logDir $i) }}
        {{- end }}
    {{- join "," $logDirs }}
    {{- else }}
        {{- printf "%s" $logDir }}
    {{- end }}
{{- end }}

{{/*
    Check whether Apache Kafka standalone brokers are to be deployed
*/}}
{{- define "application-collection.apache-kafka.areStandaloneBrokersEnabled" }}
    {{- $context := default . .context }}
    {{- if and $context.Values.broker.enabled $context.Values.broker.statefulset.enabled $context.Values.broker.podTemplates.containers.broker.enabled }}
        {{- true }}
    {{- end }}
{{- end }}

{{/*
    Return the desired nodeCount
*/}}
{{- define "application-collection.apache-kafka.nodeCount" }}
    {{- $context := default . .context }}
    {{- $nodeType := .nodeType }}
    {{- $brokerCount := 0 }}
    {{- $controllerCount := coalesce $context.Values.controller.statefulset.replicas $context.Values.cluster.nodeCount.controller }}
    {{- if eq $nodeType "controller" }}
        {{- printf "%d" (int $controllerCount) }}
    {{- else if eq $nodeType "broker" }}
        {{- if eq (include "application-collection.render.boolean" (dict "template" (include "application-collection.apache-kafka.areStandaloneBrokersEnabled" $context) "context" $context)) "true" }}
            {{- $brokerCount = coalesce $context.Values.broker.statefulset.replicas $context.Values.cluster.nodeCount.broker }}
        {{- end }}
        {{- printf "%d" (int $brokerCount) }}
    {{- end }}
{{- end }}


{{/*
    Apache Kafka Listener's security protocol map
*/}}
{{- define "application-collection.apache-kafka.protocolMap" }}
    {{- $context := default . .context }}
    {{- $protocolMap := list }}
    {{- range $listenerKey, $listenerConfig := $context.Values.cluster.listeners }}
        {{- if not (eq $listenerKey "*") }}
            {{- $protocolMap = append $protocolMap (printf "%s:%s" $listenerConfig.name $listenerConfig.protocol) }}
        {{- end }}
    {{- end }}
    {{- join "," $protocolMap }}
{{- end }}

{{/*
    Apache Kafka Listener's JAAS configuration key
*/}}
{{- define "application-collection.apache-kafka.jaasConfigKey" }}
    {{- $context := default . .context }}
    {{- $listener := .listener }}
    {{- printf "%s_%s_%s_%s" "KAFKA_LISTENER_NAME" (upper $listener.name) (upper $listener.saslMechanism) "SASL_JAAS_CONFIG" }}
{{- end }}

{{/*
    Apache Kafka Listener's JAAS configuration key
*/}}
{{- define "application-collection.apache-kafka.jaasConfigValue" }}
    {{- $context := default . .context }}
    {{- $listenerType := .listenerType }}
    {{- $listener := .listener }}
    {{- $hostname := .hostname }}
    {{- $nodeType := .nodeType }}
    {{- $loginModule := "" }}
    {{- $authData := "" }}

    {{- if eq $listener.saslMechanism "GSSAPI" }}
        {{- $mountPath := "" }}
        {{- $loginModule = "com.sun.security.auth.module.Krb5LoginModule required" }}
        {{- $serviceName := include "application-collection.render.serviceName" (dict "nodeType" $nodeType "context" $context) }}
        {{- $principal := include "application-collection.apache-kafka.podFQDN" (dict "hostname" $hostname "serviceName" $serviceName "context" $context) }}
        {{- if eq $nodeType "controller" }}
            {{- $mountPath = $context.Values.controller.podTemplates.containers.controller.volumeMounts.sasl.mountPath }}
        {{- else if eq $nodeType "broker" }}
            {{- $mountPath = $context.Values.broker.podTemplates.containers.broker.volumeMounts.sasl.mountPath }}
        {{- end }}
        {{- $keyTab := printf "%s/%s.%s" $mountPath $hostname "keytab" }}
        {{- $authData = printf "useKeyTab=true storeKey=true keyTab=%s principal=%s" $keyTab $principal }}

    {{- else if eq $listener.saslMechanism "PLAIN" }}
        {{- $loginModule = "org.apache.kafka.common.security.plain.PlainLoginModule required" }}
        {{- $authData = include "application-collection.apache-kafka.plainUsers" (dict "listenerType" $listenerType "context" $context) }}

    {{- else if eq $listener.saslMechanism "OAUTHBEARER" }}
        {{- $loginModule = "org.apache.kafka.common.security.oauthbearer.OAuthBearerLoginModule required" }}
        {{- if not (empty $context.Values.auth.sasl.oauthbearer.unsecuredLoginClaimSub) }}
            {{- $authData = printf "unsecuredLoginStringClaim_sub=%s" $context.Values.auth.sasl.oauthbearer.unsecuredLoginClaimSub }}
        {{- end }}
    {{- end }}

    {{- printf "%s %s;" $loginModule $authData }}
{{- end }}

{{/*
    Apache Kafka Listener's JAAS SASL/PLAIN users
*/}}
{{- define "application-collection.apache-kafka.plainUsers" }}
    {{- $context := default . .context }}
    {{- $listenerType := .listenerType }}
    {{- $users := list }}

    {{- if or (eq $listenerType "controller") (eq $listenerType "interbroker") }}
        {{- $users = append $users (printf "username=\"$(%s)\" password=\"$(%s)\"" "_KAFKA_INTERBROKER_USER" "_KAFKA_INTERBROKER_PASSWORD") }}
        {{- $users = append $users (printf "user_$(%s)=\"$(%s)\"" "_KAFKA_INTERBROKER_USER" "_KAFKA_INTERBROKER_PASSWORD") }}
    {{- end }}

    {{- if eq $listenerType "controller_healthcheck" }}
        {{- $users = append $users (printf "username=\"$(%s)\" password=\"$(%s)\"" "_KAFKA_INTERBROKER_USER" "_KAFKA_INTERBROKER_PASSWORD") }}
    {{- end }}

    {{- if or (eq $listenerType "client") (eq $listenerType "interbroker") (eq $listenerType "broker_healthcheck") }}
        {{- $usernames := list }}
        {{- $secretProvided := false }}

        {{- if $context.Values.auth.sasl.plain.usersExistingSecret }}
            {{- $existingSecret := lookup "v1" "Secret" $context.Release.Namespace $context.Values.auth.sasl.plain.usersExistingSecret }}
            {{- if $existingSecret }}
                {{- $secretProvided = true }}
                {{- range $secretUser, $_ := $existingSecret.data }}
                    {{- $usernames = append $usernames $secretUser }}
                {{- end }}
            {{- end }}
        {{- end }}

        {{- if not $secretProvided }}
            {{- if kindIs "map" $context.Values.auth.sasl.plain.users }}
                {{- range $username, $_ := $context.Values.auth.sasl.plain.users }}
                    {{- $usernames = append $usernames $username }}
                {{- end }}
            {{- else if kindIs "slice" $context.Values.auth.sasl.plain.users }}
                {{- range $user := $context.Values.auth.sasl.plain.users }}
                    {{- $usernames = append $usernames $user.username }}
                {{- end }}
            {{- end }}
        {{- end }}

        {{- if eq $listenerType "broker_healthcheck" }}
            {{- range $username := $usernames }}
                {{- $users = append $users (printf "username=%s password=\"$(%s)\"" $username $username) }}
                {{- break }}
            {{- end }}
        {{- else }}
            {{- range $username := $usernames }}
                {{- $users = append $users (printf "user_%s=\"$(%s)\"" $username $username) }}
            {{- end }}
        {{- end }}
    {{- end }}
    {{- join " " $users }}
{{- end }}

{{/*
    Returns the nodeID for a given node
*/}}
{{- define "application-collection.apache-kafka.getNodeID" }}
    {{- $context := default . .context }}
    {{- $hostname := .hostname }}
    {{- $minBrokerID := default 0 .minBrokerID }}
    {{- $helmID := splitList "" $hostname | last }}
    {{- add $helmID $minBrokerID }}
{{- end }}

{{/*
    Return a pod's FQDN given its hostname and service name
*/}}
{{- define "application-collection.apache-kafka.podFQDN" }}
    {{- $context := default . .context }}
    {{- $hostname := .hostname }}
    {{- $serviceName := .serviceName }}
    {{- $releaseNamespace := $context.Release.Namespace }}
    {{- $clusterDomain := $context.Values.clusterDomain }}

    {{- printf "%s.%s.%s.svc.%s" $hostname $serviceName $releaseNamespace $clusterDomain }}
{{- end }}
