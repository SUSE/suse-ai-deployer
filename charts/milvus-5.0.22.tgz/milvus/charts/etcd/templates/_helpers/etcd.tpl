{{/*
    Print true if RBAC authentication is enabled, false otherwise. Supports the following non-standard values:
    - auth.rbac.create
*/}}
{{- define "application-collection.etcd.auth.rbac.enabled" }}
    {{- if kindIs "bool" .Values.auth.rbac.create }}
        {{- .Values.auth.rbac.create }}
    {{- else }}
        {{- .Values.auth.rbac.enabled }}
    {{- end }}
{{- end }}

{{/*
    Print the existing secret name for etcd RBAC configuration. Supports the following non-standard values:
    - auth.rbac.existingSecretPasswordKey
*/}}
{{- define "application-collection.etcd.auth.rbac.rootPasswordKey" }}
    {{- coalesce .Values.auth.rbac.rootPasswordKey .Values.auth.rbac.existingSecretPasswordKey "root-password" }}
{{- end }}

{{/*
    etcd protocol to use for client connections.
*/}}
{{- define "application-collection.etcd.clientProtocol" }}
    {{- .Values.transportSecurity.client.enabled | ternary "https" "http" }}
{{- end }}

{{/*
    etcd protocol to use for peer connections.
*/}}
{{- define "application-collection.etcd.peerProtocol" }}
    {{- .Values.transportSecurity.peer.enabled | ternary "https" "http" }}
{{- end }}

{{/*
    etcd initial cluster nodes.
*/}}
{{- define "application-collection.etcd.initialCluster" }}
    {{- $initialCluster := list }}
    {{- $fullName := include "application-collection.fullName" . }}
    {{- $peerProtocol := include "application-collection.etcd.peerProtocol" . }}
    {{- $serviceName := coalesce .Values.statefulset.serviceName (include "application-collection.fullName" (dict "suffix" "headless" "context" .)) }}
    {{- $releaseNamespace := .Release.Namespace }}
    {{- $clusterDomain := .Values.clusterDomain }}
    {{- $peerPort := int .Values.containerPorts.peer }}
    {{- range $node := (until (int .Values.statefulset.replicas)) }}
        {{- $initialCluster = append $initialCluster (printf "%s-%d=%s://%s-%d.%s.%s.svc.%s:%d" $fullName $node $peerProtocol $fullName $node $serviceName $releaseNamespace $clusterDomain $peerPort) }}
    {{- end }}
    {{- join "," $initialCluster }}
{{- end }}

{{/*
    etcd endpoints.
*/}}
{{- define "application-collection.etcd.endpoints" }}
    {{- $endpoints := list }}
    {{- $fullName := include "application-collection.fullName" . }}
    {{- $clientProtocol := include "application-collection.etcd.clientProtocol" . }}
    {{- $serviceName := coalesce .Values.statefulset.serviceName (include "application-collection.fullName" (dict "suffix" "headless" "context" .)) }}
    {{- $releaseNamespace := .Release.Namespace }}
    {{- $clusterDomain := .Values.clusterDomain }}
    {{- $clientPort := int .Values.containerPorts.client }}
    {{- range $node := (until (int .Values.statefulset.replicas)) }}
        {{- $endpoints = append $endpoints (printf "%s://%s-%d.%s.%s.svc.%s:%d" $clientProtocol $fullName $node $serviceName $releaseNamespace $clusterDomain $clientPort) }}
    {{- end }}
    {{- join "," $endpoints }}
{{- end }}
