# Pytorch Helm Chart

> [PyTorch](https://pytorch.org/) is a machine learning library based on the Torch library, used for applications such as computer vision and natural language processing.

## Introduction

This Helm chart bootstraps a [PyTorch](https://pytorch.org) deployment on a [Kubernetes](http://kubernetes.io) cluster using the [Helm](https://helm.sh) package manager.

## Quick Start

```console
helm install my-release oci://dp.apps.rancher.io/charts/pytorch \
    --set global.imagePullSecrets={application-collection}
```

### Prerequisites

* Helm 3.8.0 or later.
* Kubernetes 1.26 or later (for stable GPU support).

## Install Chart

To install the Helm chart with the release name *my-release*:

```console
helm install my-release oci://dp.apps.rancher.io/charts/pytorch \
    --set global.imagePullSecrets={application-collection}
```

This deploys the application to the Kubernetes cluster using the default configuration provided by the Helm chart.

> NOTE: You can follow [these steps](https://docs.apps.rancher.io/get-started/authentication/#kubernetes)
> to create and setup the image pull secrets, if you don't have them already.

## Uninstall Chart

To uninstall the Helm chart with the release name *my-release*:

```console
helm uninstall my-release
```

This removes all the Kubernetes components associated to the Helm chart

## Values

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| affinity | object | `{}` | Affinity configurations |
| configMapExtFiles | string | `""` | Existing Kubernetes Config map that contains the folder or files you want to load in PyTorch |
| entrypointscript.arguments | list | `[]` | Entrypoint script arguments |
| entrypointscript.filename | string | `""` | Entrypoint script filename |
| fullnameOverride | string | `""` |  |
| gitClone.enabled | bool | `false` | Enable in order to download files from git repository |
| gitClone.repository | string | `""` | Repository that holds the files For example - repository: "github.com/<repository name>" Don't put https:// in front |
| gitClone.revision | string | `""` | Branch from repository to clone |
| gitClone.secretName | string | `""` | Existing Kubernetes secret which holds the authentication username and password |
| global.imagePullSecrets | list | `[]` | Global override for container image registry pull secrets |
| global.imageRegistry | string | `""` | Global override for container image registry |
| gpu.enabled | bool | `false` | Enable GPU integration |
| gpu.mig.devices | object | `{}` | Specify the mig devices and the corresponding number |
| gpu.mig.enabled | bool | `false` | Enable multiple mig devices If enabled you will have to specify the mig devices If enabled is set to false this section is ignored |
| gpu.number | int | `1` | Specify the number of GPU If you use MIG section below then this parameter is ignored |
| gpu.nvidiaResource | string | `"nvidia.com/gpu"` | only for nvidia cards; change to (example) 'nvidia.com/mig-1g.10gb' to use MIG slice |
| gpu.type | string | `"nvidia"` | GPU type: 'nvidia' or 'amd' If 'gpu.enabled', default value is nvidia If set to 'amd', this will add 'rocm' suffix to image tag if 'image.tag' is not override This is due cause AMD and CPU/CUDA are different images |
| image.pullPolicy | string | `"IfNotPresent"` |  |
| image.registry | string | `"dp.apps.rancher.io"` | Image registry to use for the pytorch container |
| image.repository | string | `"containers/pytorch"` | Image repository to use for the pytorch container |
| image.tag | string | `"2.14.0-nvidia-2.2"` | Image tag to use for the pytorch container |
| imagePullSecrets | list | `[]` | Configure imagePullSecrets to use private registry ref: <https://kubernetes.io/docs/tasks/configure-pod-container/pull-image-private-registry> |
| ingress.annotations | object | `{}` | Ingress annotations |
| ingress.className | string | `""` | Ingress ClassName |
| ingress.enabled | bool | `false` | Enable ingress |
| ingress.hosts | list | `[{"host":"chart-example.local","paths":[{"path":"/","pathType":"ImplementationSpecific"}]}]` | Ingress hosts |
| ingress.tls | list | `[]` | Ingress TLS configurations |
| livenessProbe.enabled | bool | `false` | Enable livenessProbe |
| livenessProbe.failureThreshold | int | `6` | Failure threshold for livenessProbe |
| livenessProbe.initialDelaySeconds | int | `5` | Initial delay seconds for livenessProbe |
| livenessProbe.periodSeconds | int | `5` | Period seconds for livenessProbe |
| livenessProbe.successThreshold | int | `1` | Success threshold for livenessProbe |
| livenessProbe.timeoutSeconds | int | `20` | Timeout seconds for livenessProbe |
| nameOverride | string | `""` |  |
| nodeSelector | object | `{}` | NodeSelector configurations |
| persistence.accessModes | list | `["ReadWriteOnce"]` | Persistent Volume access modes Must match those of existing PV or dynamic provisioner Ref: http://kubernetes.io/docs/user-guide/persistent-volumes/ |
| persistence.annotations | object | `{}` | server data Persistent Volume annotations |
| persistence.enabled | bool | `false` | Enable persistence using PVC |
| persistence.existingClaim | string | `""` | If you'd like to bring your own PVC for persisting state, pass the name of the created + ready PVC here. If set, this Chart will not create the default PVC. Requires server.persistentVolume.enabled: true |
| persistence.size | string | `"30Gi"` | server data Persistent Volume size |
| persistence.storageClass | string | `""` | server data Persistent Volume Storage Class If defined, storageClassName: <storageClass> |
| persistence.subPath | string | `""` |  |
| persistence.volumeMode | string | `""` |  |
| persistence.volumeName | string | `""` | Pre-existing PV to attach this claim to Useful if a CSI auto-provisions a PV for you and you want to always reference the PV moving forward |
| podAnnotations | object | `{}` |  |
| podLabels | object | `{}` |  |
| podSecurityContext | object | `{}` |  |
| readinessProbe.enabled | bool | `false` | Enable readinessProbe |
| readinessProbe.failureThreshold | int | `6` | Failure threshold for readinessProbe |
| readinessProbe.initialDelaySeconds | int | `5` | Initial delay seconds for readinessProbe |
| readinessProbe.periodSeconds | int | `5` | Period seconds for readinessProbe |
| readinessProbe.successThreshold | int | `1` | Success threshold for readinessProbe |
| readinessProbe.timeoutSeconds | int | `20` | Timeout seconds for readinessProbe |
| resources.limits | object | `{}` | Pod limit |
| resources.requests | object | `{}` | Pod requests |
| runtimeClassName | string | `""` |  |
| securityContext | object | `{}` |  |
| service.annotations | object | `{}` | Annotations to add to the service |
| service.containerPort | string | `nil` |  |
| service.enabled | bool | `false` |  |
| service.loadBalancerClass | string | `nil` |  |
| service.loadBalancerIP | string | `nil` | Load Balancer IP address |
| service.nodePort | string | `""` | Service node port when service type is 'NodePort' |
| service.port | string | `nil` | Service port |
| service.type | string | `"ClusterIP"` | Service type |
| serviceAccount.annotations | object | `{}` | Annotations to add to the service account |
| serviceAccount.automount | bool | `true` | Automatically mount a ServiceAccount's API credentials? |
| serviceAccount.create | bool | `false` | Specifies whether a service account should be created |
| serviceAccount.name | string | `""` | The name of the service account to use. If not set and create is true, a name is generated using the fullname template |
| tolerations | list | `[]` | Tolerations configurations |
| volumeMounts | list | `[]` | Additional volumeMounts on the output Deployment definition. |
| volumes | list | `[]` | Additional volumes on the output Deployment definition. |

### Override Values

To override a parameter, add *--set* flags to the *helm install* command. For example:

```console
helm install my-release --set image.tag=2.14.0 oci://dp.apps.rancher.io/charts/pytorch
```

Alternatively, you can override the parameter values using a custom YAML file with the *-f* flag. For example:

```console
helm install my-release -f custom-values.yaml oci://dp.apps.rancher.io/charts/pytorch
```

Read more about [Values files](https://helm.sh/docs/chart_template_guide/values_files/) in the [Helm documentation](https://helm.sh/docs/).

## Interact with Pytorch

Pytorch documentation can be found [here](https://github.com/pytorch/pytorch/tree/main/docs).

To inject the files into the container, there are 3 options. In order of priority, they are:

- Existing Kubernetes configmap that contains the folder or files you want to load in PyTorch.
- Files under the local folder which is part of Helm chart.
- Cloning a git repository.

### Use an existing ConfigMap

To use an existing config map, set `configMapExtFiles=<config-map>` in the `values.yaml` file.

### Load files from a local folder

To load files from local folder you don't have to set any option. Just create local folder and add files in there at the same level as `values.yaml` in PyTorch Helm chart.

Important: Don't define `configMapExtFiles` in `values.yaml`.

### Clone a Git repository

To clone a Git repository make sure that there are no files in scripts folder and configMapExtFiles option is not set in values file. Also the `gitClone.repository` link shouldn't have `https://` in front of it.

## Examples

### Basic values.yaml file with GPU and existing configmap

```yaml
gpu:
  # -- Enable GPU integration
  enabled: true
  # -- GPU type: 'nvidia' or 'amd'
  type: 'nvidia'
  # -- Specify the number of GPU to 1
  number: 1

# -- Specify runtime class
runtimeClassName: "nvidia"

# -- Existing Kubernetes Config map that contains the folder or files you want to load in PyTorch.
configMapExtFiles: <existing ConfigMap name>
```

### Basic values.yaml example which downloads files from git repsitory

```yaml
gitClone:
  # -- Enable in order to download files from git repository.
  enabled: true
  # -- Repository that holds the files (note: without the protocol, i.e. without 'https://').
  # Note: Don't provide https
  repository: "github.com/<Name of repository>"
  # -- Branch from repository to clone.
  revision: "<Branch from which to download files>"
  # -- Existing Kubernetes secret which holds the authentication username and password fot the github repository. If repo doesn't need authentication leave this blank.
  secretName: "<Kubernetes secret Name>"

# -- Existing Kubernetes Config map that contains the folder or files you want to load in PyTorch.
configMapExtFiles: ""
```
