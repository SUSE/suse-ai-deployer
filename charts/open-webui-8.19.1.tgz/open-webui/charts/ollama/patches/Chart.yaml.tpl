# SPDX-License-Identifier: MIT
#!BuildTag: charts/ollama:${VERSION}-%RELEASE%
#!BuildTag: charts/ollama:${VERSION}
annotations:
  helm.sh/images: |
    - image: ${CONTAINER_REGISTRY}/containers/ollama:0.12.9-11.15
      name: ollama
    - image: ${CONTAINER_REGISTRY}/containers/bci-busybox:15.7-19.10
      name: bci-busybox
  license: MIT
apiVersion: v2
appVersion: ${APP_VERSION}
description: Get up and running with Llama 3.2, Mistral, Gemma 2, and other large language models.
home: https://apps.rancher.io/applications/ollama
icon: https://apps.rancher.io/logos/ollama.png
keywords:
  - ai
  - llm
  - llama
  - mistral
kubeVersion: ^1.16.0-0
maintainers:
  - url: https://www.suse.com
    name: SUSE LLC
name: ollama
sources:
  - https://github.com/ollama/ollama
type: application
version: ${VERSION}
